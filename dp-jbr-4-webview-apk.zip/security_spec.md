# Security Specification: DP JBR 4 (Dropping Jember 4)

## 1. Data Invariants
1. Admin (Koordinator) has global read and write privileges over all collections (`members`, `daily_inputs`, `targets`, `plastics_bottles`, `customers`, `propaganda`, `admins`).
2. Yakult Lady members can read members directory to coordinate routes.
3. Yakult Lady can only create and update records (`daily_inputs`, `plastics_bottles`, `customers`, `propaganda`) that belong to their own identity (`ownerUid == request.auth.uid` or assigned `memberId`).
4. Nobody can spoof administrative roles without existing in `/admins/{adminUid}`.
5. All IDs must adhere to valid alphanumeric characters and length limits (`isValidId`).
6. All string fields have strict length checks, preventing denial of wallet attacks.

## 2. The Dirty Dozen Payloads
1. **Unauthenticated Write**: Attempting to create `daily_inputs` without auth token (`request.auth == null`). Result: DENIED.
2. **Member Identity Hijack**: Yakult Lady A attempting to create a daily input with `ownerUid` set to Yakult Lady B's UID. Result: DENIED.
3. **Ghost Fields Injection**: Sending a payload with extra unauthorized field `isSuperAdmin: true` in `daily_inputs`. Result: DENIED.
4. **Massive Payload String (Denial of Wallet)**: Submitting 100KB notes string in `daily_inputs`. Result: DENIED.
5. **Self-Promote to Admin**: Normal Yakult Lady writing her own UID into `/admins/{uid}`. Result: DENIED.
6. **Target Tampering by YL**: Non-admin attempting to overwrite monthly targets in `/targets/{targetId}`. Result: DENIED.
7. **Negative Stock Dropping**: Inputting negative dropping or negative sales botol numbers. Result: DENIED.
8. **Path ID Injection**: Submitting an ID containing path traversal characters like `../../admin`. Result: DENIED.
9. **Unverified Email Privilege Escalation**: Claiming admin email without verification. Result: DENIED.
10. **Foreign Customer Delete**: Member A trying to delete Member B's customer document. Result: DENIED.
11. **Altering Immutable Creation Time**: Attempting to rewrite `createdAt` on an existing document. Result: DENIED.
12. **Blanket Query Scraping**: Attempting an unrestricted list read without matching the user's records. Result: DENIED.
