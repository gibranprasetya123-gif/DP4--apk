/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MenuId } from './types';
import { Navbar } from './components/layout/Navbar';
import { BottomNav } from './components/layout/BottomNav';
import { MenuDrawer } from './components/layout/MenuDrawer';
import { LoginModal } from './components/auth/LoginModal';

// Pages / 10 Menus
import { DashboardView } from './components/pages/DashboardView';
import { DailyInputView } from './components/pages/DailyInputView';
import { PdmView } from './components/pages/PdmView';
import { ReturnBottlesView } from './components/pages/ReturnBottlesView';
import { SummaryView } from './components/pages/SummaryView';
import { TargetView } from './components/pages/TargetView';
import { PlasticsBottlesView } from './components/pages/PlasticsBottlesView';
import { CustomersView } from './components/pages/CustomersView';
import { PropagandaView } from './components/pages/PropagandaView';
import { ChartsView } from './components/pages/ChartsView';
import { MembersView } from './components/pages/MembersView';
import { SettingsView } from './components/pages/SettingsView';

const MainLayout: React.FC = () => {
  const [activeMenu, setActiveMenu] = useState<MenuId>('dashboard');
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Render the selected view
  const renderCurrentView = () => {
    switch (activeMenu) {
      case 'dashboard':
        return <DashboardView onNavigate={(menu) => setActiveMenu(menu)} />;
      case 'input_harian':
        return <DailyInputView />;
      case 'pdm':
        return <PdmView />;
      case 'kembali_botol':
        return <ReturnBottlesView />;
      case 'ringkasan':
        return <SummaryView />;
      case 'target_yl':
        return <TargetView />;
      case 'plastik_botol':
        return <PlasticsBottlesView />;
      case 'pelanggan':
        return <CustomersView />;
      case 'propaganda':
        return <PropagandaView />;
      case 'grafik':
        return <ChartsView />;
      case 'data_anggota':
        return <MembersView />;
      case 'pengaturan':
        return <SettingsView />;
      default:
        return <DashboardView onNavigate={(menu) => setActiveMenu(menu)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col antialiased selection:bg-emerald-100 selection:text-emerald-900 font-sans">
      {/* Mobile-sized shell or responsive container */}
      <div className="w-full max-w-md mx-auto min-h-screen bg-slate-50 flex flex-col shadow-xl relative border-x border-slate-200/60">
        {/* Top Header */}
        <Navbar
          onOpenLogin={() => setIsLoginModalOpen(true)}
          onOpenMenu={() => setIsMenuDrawerOpen(true)}
        />

        {/* Main Content Area with padding for bottom nav */}
        <main className="flex-1 px-3.5 pt-3.5 overflow-y-auto">
          {renderCurrentView()}
        </main>

        {/* Ergonomic Mobile Bottom Nav Bar */}
        <BottomNav
          activeMenu={activeMenu}
          onSelectMenu={(menu) => {
            setActiveMenu(menu);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenMenuDrawer={() => setIsMenuDrawerOpen(true)}
        />

        {/* All 10 Menus Drawer Modal */}
        <MenuDrawer
          isOpen={isMenuDrawerOpen}
          onClose={() => setIsMenuDrawerOpen(false)}
          activeMenu={activeMenu}
          onSelectMenu={(menu) => {
            setActiveMenu(menu);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />

        {/* Login & Profile Selector Modal */}
        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
        />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
