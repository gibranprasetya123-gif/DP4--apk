import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  ShieldCheck,
  User,
  LogIn,
  LogOut,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const {
    user,
    activeMember,
    allMembers,
    isAdmin,
    signInWithGoogle,
    signOut,
    switchActiveMember,
  } = useAuth();

  const [loadingGoogle, setLoadingGoogle] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    setLoadingGoogle(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal masuk dengan Google. Silakan coba lagi.');
    } finally {
      setLoadingGoogle(false);
    }
  };

  const handleSelectMember = (memberId: string) => {
    switchActiveMember(memberId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-emerald-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-red-600 font-black">
              Y
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Masuk & Profil Anggota</h3>
              <p className="text-xs text-emerald-200">DP JBR 4 &bull; Dropping Jember 4</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Active Status Card */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-base shrink-0 shadow-xs">
              {isAdmin ? (
                <ShieldCheck className="w-6 h-6" />
              ) : (
                <User className="w-6 h-6" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold tracking-wider uppercase text-emerald-800 bg-emerald-200/70 px-2 py-0.5 rounded-full inline-block mb-1">
                Profil Aktif Saat Ini
              </span>
              <p className="font-bold text-slate-800 text-sm truncate">{activeMember.name}</p>
              <p className="text-xs text-slate-600 truncate">
                {isAdmin ? 'Hak Akses: Seluruh Data DP JBR 4' : `Area: ${activeMember.routeArea}`}
              </p>
            </div>
          </div>

          {/* Firebase Authentication via Google */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Firebase Authentication
              </span>
              {user ? (
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Terautentikasi
                </span>
              ) : (
                <span className="text-[11px] text-slate-500">Belum login</span>
              )}
            </div>

            {user ? (
              <div className="space-y-2">
                <div className="p-2.5 bg-slate-50 rounded-lg text-xs space-y-0.5 text-slate-600">
                  <p className="font-semibold text-slate-800">{user.displayName || 'Akun Google'}</p>
                  <p className="truncate text-slate-500">{user.email}</p>
                  <p className="text-[10px] font-mono text-slate-400">UID: {user.uid.slice(0, 16)}...</p>
                </div>
                <button
                  onClick={signOut}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 border border-red-200 hover:bg-red-50 text-red-600 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" /> Keluar dari Akun Google
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-slate-600">
                  Login dengan Google untuk otentikasi resmi dan penyimpanan Cloud Firestore.
                </p>
                <button
                  onClick={handleGoogleLogin}
                  disabled={loadingGoogle}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold text-xs rounded-xl transition-all shadow-xs cursor-pointer active:scale-98"
                >
                  {/* Google 'G' icon */}
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  {loadingGoogle ? 'Menghubungkan...' : 'Masuk dengan Akun Google'}
                </button>
              </div>
            )}

            {errorMsg && (
              <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded-lg flex items-start gap-1.5 border border-red-200">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}
          </div>

          {/* Switch Profile Selection (1 Admin + 7 Yakult Lady) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Pilih Profil Anggota DP JBR 4
              </span>
              <span className="text-[11px] text-slate-500">1 Admin &bull; 7 YL</span>
            </div>
            <p className="text-xs text-slate-500">
              Pilih identitas Anda untuk menguji hak akses (Admin melihat seluruh data, Anggota hanya melihat data sendiri).
            </p>

            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {allMembers.map((m) => {
                const isCurrent = activeMember.memberId === m.memberId;
                const isAdm = m.role === 'admin';
                return (
                  <button
                    key={m.memberId}
                    onClick={() => handleSelectMember(m.memberId)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isCurrent
                        ? 'bg-emerald-50 border-emerald-500 shadow-xs ring-1 ring-emerald-400'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                          isAdm
                            ? 'bg-emerald-800 text-white'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {isAdm ? (
                          <ShieldCheck className="w-4 h-4" />
                        ) : (
                          m.code.replace('YL-', '')
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="font-bold text-xs text-slate-800 truncate">{m.name}</p>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                              isAdm
                                ? 'bg-purple-100 text-purple-700'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {m.code}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">{m.routeArea}</p>
                      </div>
                    </div>

                    {isCurrent && (
                      <span className="text-emerald-700 shrink-0 font-bold text-xs">
                        Aktif
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center">
          <p className="text-[11px] text-slate-500">
            Aplikasi Administrasi Resmi &bull; Yakult Dropping Jember 4
          </p>
        </div>
      </div>
    </div>
  );
};
