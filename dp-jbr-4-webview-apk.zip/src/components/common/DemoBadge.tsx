import React from 'react';
import { Sparkles, Database } from 'lucide-react';

interface DemoBadgeProps {
  isDemo?: boolean;
  className?: string;
}

export const DemoBadge: React.FC<DemoBadgeProps> = ({ isDemo = true, className = '' }) => {
  if (isDemo) {
    return (
      <span
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-100 text-amber-800 border border-amber-300 shadow-xs ${className}`}
        title="Data contoh untuk preview antarmuka"
      >
        <Sparkles className="w-3 h-3 text-amber-600 animate-pulse" />
        DEMO
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs ${className}`}
      title="Tersimpan langsung di Cloud Firestore"
    >
      <Database className="w-3 h-3 text-emerald-600" />
      FIRESTORE
    </span>
  );
};
