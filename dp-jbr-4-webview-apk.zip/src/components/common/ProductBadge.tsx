import React from 'react';
import { ProductCode } from '../../types';
import { PRODUCT_VARIANTS } from '../../data/productVariants';

interface ProductBadgeProps {
  code: ProductCode;
  showName?: boolean;
  count?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const ProductBadge: React.FC<ProductBadgeProps> = ({
  code,
  showName = false,
  count,
  size = 'md',
  className = '',
}) => {
  const variant = PRODUCT_VARIANTS[code];
  if (!variant) return null;

  const sizeClasses = {
    sm: 'text-[9px] px-1.5 py-0.5 font-bold',
    md: 'text-[11px] px-2 py-0.5 font-extrabold',
    lg: 'text-xs px-2.5 py-1 font-black',
  };

  return (
    <span
      style={{ backgroundColor: variant.hex }}
      className={`inline-flex items-center gap-1 rounded-md text-white shadow-xs tracking-wider uppercase ${sizeClasses[size]} ${className}`}
      title={`${variant.fullName} (${variant.hex})`}
    >
      <span>{variant.code}</span>
      {showName && (
        <span className="opacity-90 font-medium normal-case">
          {variant.name}
        </span>
      )}
      {count !== undefined && (
        <span className="bg-white/25 px-1 py-0.2 rounded text-[10px] font-mono ml-0.5">
          {count}
        </span>
      )}
    </span>
  );
};
