import React from 'react';
import { MenuId } from '../../types';
import {
  LayoutDashboard,
  ClipboardPenLine,
  ClipboardList,
  RotateCcw,
  FileSpreadsheet,
  Menu,
} from 'lucide-react';

interface BottomNavProps {
  activeMenu: MenuId;
  onSelectMenu: (menu: MenuId) => void;
  onOpenMenuDrawer: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeMenu,
  onSelectMenu,
  onOpenMenuDrawer,
}) => {
  // Check if current menu is one of the 5 primary ones shown directly on bottom bar
  const isPrimaryMenu = [
    'dashboard',
    'input_harian',
    'pdm',
    'kembali_botol',
    'ringkasan',
  ].includes(activeMenu);

  const getSecondaryMenuLabel = () => {
    switch (activeMenu) {
      case 'target_yl':
        return 'Target';
      case 'pelanggan':
        return 'Pelanggan';
      case 'propaganda':
        return 'Propaganda';
      case 'grafik':
        return 'Grafik';
      case 'data_anggota':
        return 'Anggota';
      case 'pengaturan':
        return 'Pengaturan';
      case 'plastik_botol':
        return 'Arsip';
      default:
        return 'Menu';
    }
  };

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] pb-[env(safe-area-inset-bottom)]"
      role="navigation"
      aria-label="Navigasi Menu Utama HP"
    >
      <div className="max-w-md mx-auto px-1 py-1 flex items-center justify-between">
        {/* 1. Dashboard */}
        <button
          onClick={() => onSelectMenu('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            activeMenu === 'dashboard'
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg ${
              activeMenu === 'dashboard' ? 'bg-emerald-100 text-emerald-800' : ''
            }`}
          >
            <LayoutDashboard className="w-4.5 h-4.5" />
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight">Dashboard</span>
        </button>

        {/* 2. Input Harian */}
        <button
          onClick={() => onSelectMenu('input_harian')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            activeMenu === 'input_harian'
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg relative ${
              activeMenu === 'input_harian'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-700'
            }`}
          >
            <ClipboardPenLine className="w-4.5 h-4.5" />
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight">Input</span>
        </button>

        {/* 3. PDM (Pesanan Di Muka) - NEW MENU */}
        <button
          onClick={() => onSelectMenu('pdm')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            activeMenu === 'pdm'
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg relative ${
              activeMenu === 'pdm' ? 'bg-emerald-100 text-emerald-800 font-bold' : ''
            }`}
          >
            <ClipboardList className="w-4.5 h-4.5" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-600 rounded-full"></span>
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight">PDM</span>
        </button>

        {/* 4. Kembali Botol (Otomatis: PDM - Penjualan) - REPLACED MENU */}
        <button
          onClick={() => onSelectMenu('kembali_botol')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            activeMenu === 'kembali_botol'
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg relative ${
              activeMenu === 'kembali_botol' ? 'bg-emerald-100 text-emerald-800' : ''
            }`}
          >
            <RotateCcw className="w-4.5 h-4.5" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-teal-500 rounded-full"></span>
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight truncate">Kembali</span>
        </button>

        {/* 5. Ringkasan */}
        <button
          onClick={() => onSelectMenu('ringkasan')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            activeMenu === 'ringkasan'
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg ${
              activeMenu === 'ringkasan' ? 'bg-emerald-100 text-emerald-800' : ''
            }`}
          >
            <FileSpreadsheet className="w-4.5 h-4.5" />
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight">Ringkasan</span>
        </button>

        {/* 6. Menu Lainnya (Target, Pelanggan, Propaganda, Grafik, Anggota, Pengaturan) */}
        <button
          onClick={onOpenMenuDrawer}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all cursor-pointer ${
            !isPrimaryMenu
              ? 'text-emerald-800 font-extrabold'
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <div
            className={`p-1 rounded-lg relative ${
              !isPrimaryMenu ? 'bg-emerald-100 text-emerald-800 ring-1 ring-emerald-300' : ''
            }`}
          >
            <Menu className="w-4.5 h-4.5" />
          </div>
          <span className="text-[9.5px] mt-0.5 tracking-tight truncate max-w-[50px]">
            {!isPrimaryMenu ? getSecondaryMenuLabel() : 'Lainnya'}
          </span>
        </button>
      </div>
    </nav>
  );
};
