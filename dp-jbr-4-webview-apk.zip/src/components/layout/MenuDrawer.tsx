import React from 'react';
import { MenuId, MenuItem } from '../../types';
import {
  LayoutDashboard,
  ClipboardPenLine,
  ClipboardList,
  RotateCcw,
  FileSpreadsheet,
  Target,
  Package,
  Users,
  Megaphone,
  TrendingUp,
  ContactRound,
  Settings,
  X,
  ChevronRight,
  Archive,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeMenu: MenuId;
  onSelectMenu: (menu: MenuId) => void;
}

export const ALL_MENU_ITEMS: MenuItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    description: 'Ringkasan KPI, penjualan botol, dan status tim hari ini',
    iconName: 'LayoutDashboard',
  },
  {
    id: 'input_harian',
    label: 'Input Harian',
    description: 'Form input dropping, botol terjual, sisa, dan setoran kas',
    iconName: 'ClipboardPenLine',
    badge: 'Utama',
  },
  {
    id: 'pdm',
    label: 'PDM (Pesanan Di Muka)',
    description: 'Pencatatan pesanan di muka 4 varian produk Yakult per anggota',
    iconName: 'ClipboardList',
    badge: 'Baru',
  },
  {
    id: 'kembali_botol',
    label: 'Kembali Botol',
    description: 'Perhitungan otomatis: PDM dikurangi botol terjual (YO, OM, OS, YT)',
    iconName: 'RotateCcw',
    badge: 'Otomatis',
  },
  {
    id: 'ringkasan',
    label: 'Ringkasan',
    description: 'Laporan rekap harian, mingguan, bulanan per YL & total DP',
    iconName: 'FileSpreadsheet',
  },
  {
    id: 'target_yl',
    label: 'Target YL',
    description: 'Target botol harian/bulanan, pelanggan baru, dan capaian',
    iconName: 'Target',
  },
  {
    id: 'pelanggan',
    label: 'Pelanggan',
    description: 'Database pelanggan rute, kontak WA, dan jadwal antar',
    iconName: 'Users',
  },
  {
    id: 'propaganda',
    label: 'Propaganda',
    description: 'Catatan edukasi kesehatan usus, sampling, dan prospek baru',
    iconName: 'Megaphone',
  },
  {
    id: 'grafik',
    label: 'Grafik',
    description: 'Tren penjualan, grafik komparasi 7 YL & distribusi produk',
    iconName: 'TrendingUp',
  },
  {
    id: 'data_anggota',
    label: 'Data Anggota',
    description: 'Profil 7 Yakult Lady & Admin, rute area, dan status aktif',
    iconName: 'ContactRound',
  },
  {
    id: 'pengaturan',
    label: 'Pengaturan',
    description: 'Pengaturan akun, sinkronisasi Firestore & kelola data demo',
    iconName: 'Settings',
  },
];

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  activeMenu,
  onSelectMenu,
}) => {
  const { isAdmin, activeMember } = useAuth();

  if (!isOpen) return null;

  const renderIcon = (name: string, active: boolean) => {
    const className = `w-5 h-5 shrink-0 ${active ? 'text-emerald-700' : 'text-slate-600'}`;
    switch (name) {
      case 'LayoutDashboard':
        return <LayoutDashboard className={className} />;
      case 'ClipboardPenLine':
        return <ClipboardPenLine className={className} />;
      case 'ClipboardList':
        return <ClipboardList className={className} />;
      case 'RotateCcw':
        return <RotateCcw className={className} />;
      case 'FileSpreadsheet':
        return <FileSpreadsheet className={className} />;
      case 'Target':
        return <Target className={className} />;
      case 'Package':
        return <Package className={className} />;
      case 'Users':
        return <Users className={className} />;
      case 'Megaphone':
        return <Megaphone className={className} />;
      case 'TrendingUp':
        return <TrendingUp className={className} />;
      case 'ContactRound':
        return <ContactRound className={className} />;
      case 'Settings':
        return <Settings className={className} />;
      default:
        return <LayoutDashboard className={className} />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Background click dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Drawer Container */}
      <div className="relative w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl max-h-[88vh] flex flex-col shadow-2xl z-10 overflow-hidden animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-emerald-900 text-white">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-lg leading-tight">Daftar Menu DP JBR 4</h2>
              <span className="bg-emerald-700 text-emerald-100 text-xs px-2 py-0.5 rounded-full font-medium">
                {ALL_MENU_ITEMS.length} Menu
              </span>
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">
              Administrasi & monitoring kinerja lengkap Dropping Jember 4
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Tutup Menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current profile info strip */}
        <div className="px-4 py-2 bg-emerald-50/70 border-b border-emerald-100 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-emerald-900">
            <span className="font-semibold">{activeMember.name}</span>
            <span className="text-emerald-700">({isAdmin ? 'Admin Koordinator' : activeMember.code})</span>
          </div>
          <span className="text-emerald-700 text-[11px] font-medium">
            {isAdmin ? 'Hak Akses Semua Data' : 'Data Khusus Milik Sendiri'}
          </span>
        </div>

        {/* List of Menu Items */}
        <div className="p-3 overflow-y-auto space-y-1.5 divide-y divide-slate-100/60 max-h-[60vh]">
          {ALL_MENU_ITEMS.map((item, idx) => {
            const isActive = activeMenu === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectMenu(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3.5 p-3 rounded-xl transition-all cursor-pointer text-left ${
                  isActive
                    ? 'bg-emerald-50 border border-emerald-200 shadow-xs'
                    : 'hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {renderIcon(item.iconName, isActive)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400 font-mono w-4">
                      {idx + 1}.
                    </span>
                    <span className={`text-sm font-bold truncate ${isActive ? 'text-emerald-900' : 'text-slate-800'}`}>
                      {item.label}
                    </span>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                          item.badge === 'Baru'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.badge === 'Otomatis'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 truncate mt-0.5">
                    {item.description}
                  </p>
                </div>

                <ChevronRight className={`w-4 h-4 ${isActive ? 'text-emerald-700' : 'text-slate-300'}`} />
              </button>
            );
          })}
        </div>

        {/* Bottom Drawer Footer with Historical Archive Link */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <button
            onClick={() => {
              onSelectMenu('plastik_botol');
              onClose();
            }}
            className="flex items-center gap-1 text-slate-500 hover:text-slate-700 font-medium cursor-pointer"
            title="Data historis botol rusak & sarana plastik"
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Arsip Sarana & Botol Kosong</span>
          </button>

          <button
            onClick={() => {
              onSelectMenu('pengaturan');
              onClose();
            }}
            className="text-emerald-700 font-semibold hover:underline cursor-pointer"
          >
            Pengaturan &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
