import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, UserCheck, Wifi, WifiOff, LogIn, RefreshCw, User as UserIcon } from 'lucide-react';
import { DemoBadge } from '../common/DemoBadge';

interface NavbarProps {
  onOpenLogin: () => void;
  onOpenMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenLogin, onOpenMenu }) => {
  const { user, activeMember, isAdmin, isOnline, useDemoData } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-emerald-900 text-white shadow-md border-b border-emerald-800/80">
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand & Area */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center shadow-inner shrink-0 p-1">
            {/* Iconic Yakult Bottle Silhouette SVG */}
            <svg viewBox="0 0 24 24" className="w-full h-full text-red-600 fill-current" aria-label="Yakult Logo">
              <path d="M9 2h6v2h1v3h-1v2c1.5 1 2 2.5 2 4.5 0 2.5-1 4.5-1 7.5H7c0-3-1-5-1-7.5 0-2 0.5-3.5 2-4.5V7H7V4h1V2h1zm1 2v1h4V4h-4zm-1 3v2.2l.5.3c1.2.7 1.5 1.7 1.5 3.5 0 2.5-1 4.5-1 7h7c0-2.5-1-4.5-1-7 0-1.8.3-2.8 1.5-3.5l.5-.3V7H9z" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight leading-none text-white">DP JBR 4</span>
              <span className="bg-emerald-700/80 text-[10px] px-1.5 py-0.5 rounded text-emerald-100 font-semibold">Jember 4</span>
              {useDemoData && <DemoBadge isDemo={true} />}
            </div>
            <p className="text-[11px] text-emerald-200 font-medium leading-tight">Yakult Lady Performance</p>
          </div>
        </div>

        {/* Right side: Firestore status & Active Profile */}
        <div className="flex items-center gap-2">
          {/* Firestore Connection status */}
          <div
            className={`hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${
              isOnline
                ? 'bg-emerald-800/70 border-emerald-600/60 text-emerald-200'
                : 'bg-red-950/70 border-red-700/70 text-red-200'
            }`}
            title={isOnline ? 'Terhubung ke Cloud Firestore' : 'Mode Offline'}
          >
            {isOnline ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Firestore Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-red-400" />
                <span>Offline</span>
              </>
            )}
          </div>

          {/* Active Profile Pill / Login button */}
          <button
            onClick={onOpenLogin}
            className="flex items-center gap-2 bg-emerald-800 hover:bg-emerald-700 transition-colors px-2.5 py-1.5 rounded-lg border border-emerald-600/60 shadow-xs cursor-pointer active:scale-95"
            title="Klik untuk ganti profil / login akun"
          >
            <div className="w-6 h-6 rounded-full bg-white text-emerald-900 flex items-center justify-center font-bold text-xs shrink-0">
              {isAdmin ? (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              ) : (
                <UserIcon className="w-3.5 h-3.5 text-emerald-800" />
              )}
            </div>
            <div className="text-left leading-tight hidden xs:block">
              <p className="text-xs font-semibold text-white truncate max-w-[100px]">{activeMember.name}</p>
              <p className="text-[10px] text-emerald-200">
                {isAdmin ? 'Admin Koordinator' : activeMember.code}
              </p>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
};
