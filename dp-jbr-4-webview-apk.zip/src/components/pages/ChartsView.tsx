import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DailyInput } from '../../types';
import { subscribeDailyInputs } from '../../firebase/service';
import { DEMO_DAILY_INPUTS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS } from '../../data/productVariants';
import {
  TrendingUp,
  BarChart2,
  PieChart,
  Award,
  Layers,
  Sparkles,
  Package,
} from 'lucide-react';

export const ChartsView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [inputs, setInputs] = useState<DailyInput[]>([]);

  useEffect(() => {
    const unsub = subscribeDailyInputs(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setInputs(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_DAILY_INPUTS
            : DEMO_DAILY_INPUTS.filter((d) => d.memberId === activeMember.memberId);
          setInputs(filtered);
        } else {
          setInputs([]);
        }
      }
    );
    return () => unsub();
  }, [activeMember.memberId, isAdmin, useDemoData]);

  // 4 Varian Produk Yakult
  // 1. YO = MERAH (#D92D32)
  // 2. OM = ORANYE (#F28C28)
  // 3. OS = PINK (#E875A9)
  // 4. YT = BIRU (#2689D8)
  const totalYO = inputs.reduce(
    (sum, i) => sum + (i.soldYO ?? (i.soldRegular ? Math.round(i.soldRegular * 0.75) : 0)),
    0
  );
  const totalOM = inputs.reduce(
    (sum, i) =>
      sum +
      (i.soldOM ??
        (i.soldRegular ? i.soldRegular - Math.round(i.soldRegular * 0.75) : 0)),
    0
  );
  const totalOS = inputs.reduce(
    (sum, i) => sum + (i.soldOS ?? (i.soldLight ? Math.round(i.soldLight * 0.55) : 0)),
    0
  );
  const totalYT = inputs.reduce(
    (sum, i) =>
      sum +
      (i.soldYT ??
        (i.soldLight ? i.soldLight - Math.round(i.soldLight * 0.55) : 0)),
    0
  );

  const totalRegular = inputs.reduce((sum, i) => sum + (i.soldRegular || 0), 0);
  const totalLight = inputs.reduce((sum, i) => sum + (i.soldLight || 0), 0);
  const totalSold = totalYO + totalOM + totalOS + totalYT || (totalRegular + totalLight);

  const yoPct = totalSold > 0 ? Math.round((totalYO / totalSold) * 100) : 55;
  const omPct = totalSold > 0 ? Math.round((totalOM / totalSold) * 100) : 20;
  const osPct = totalSold > 0 ? Math.round((totalOS / totalSold) * 100) : 13;
  const ytPct = totalSold > 0 ? Math.max(0, 100 - (yoPct + omPct + osPct)) : 12;

  // Comparison for 7 Yakult Lady
  const ylMembers = allMembers.filter((m) => m.role === 'yl');
  const memberPerformances = ylMembers.map((member) => {
    const mInputs = inputs.filter((i) => i.memberId === member.memberId);
    const mSold = mInputs.reduce(
      (sum, i) =>
        sum +
        (i.soldYO ?? (i.soldRegular ? Math.round(i.soldRegular * 0.75) : 0)) +
        (i.soldOM ?? (i.soldRegular ? Math.round(i.soldRegular * 0.25) : 0)) +
        (i.soldOS ?? (i.soldLight ? Math.round(i.soldLight * 0.55) : 0)) +
        (i.soldYT ?? (i.soldLight ? Math.round(i.soldLight * 0.45) : 0)),
      0
    ) || mInputs.reduce((sum, i) => sum + (i.soldRegular || 0) + (i.soldLight || 0), 0);

    const mYO = mInputs.reduce(
      (sum, i) => sum + (i.soldYO ?? (i.soldRegular ? Math.round(i.soldRegular * 0.75) : 0)),
      0
    );
    const mOM = mInputs.reduce(
      (sum, i) =>
        sum + (i.soldOM ?? (i.soldRegular ? Math.round(i.soldRegular * 0.25) : 0)),
      0
    );
    const mOS = mInputs.reduce(
      (sum, i) => sum + (i.soldOS ?? (i.soldLight ? Math.round(i.soldLight * 0.55) : 0)),
      0
    );
    const mYT = mInputs.reduce(
      (sum, i) => sum + (i.soldYT ?? (i.soldLight ? Math.round(i.soldLight * 0.45) : 0)),
      0
    );

    const mDrop = mInputs.reduce((sum, i) => sum + (i.droppingStock || 0), 0);
    const efficiency = mDrop > 0 ? Math.round((mSold / mDrop) * 100) : 0;
    return {
      memberId: member.memberId,
      name: member.name,
      code: member.code,
      sold: mSold,
      mYO,
      mOM,
      mOS,
      mYT,
      dropping: mDrop,
      efficiency,
    };
  });

  // Find max sold for bar normalization
  const maxSold = Math.max(1, ...memberPerformances.map((m) => m.sold));

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-700" />
            Grafik Penjualan 4 Varian
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Komposisi YO, OM, OS, YT & komparasi kinerja 7 Yakult Lady DP JBR 4
          </p>
        </div>

        {useDemoData && inputs.some((i) => i.isDemo) && <DemoBadge isDemo={true} />}
      </div>

      {/* Chart 1: Rasio Penjualan 4 Varian Produk */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PieChart className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-800">
              Distribusi 4 Varian Produk
            </h3>
          </div>
          <span className="text-xs text-slate-600 font-extrabold bg-slate-100 px-2 py-0.5 rounded-md">
            Total {totalSold.toLocaleString('id-ID')} btl
          </span>
        </div>

        {/* Multi-segment Horizontal Bar */}
        <div className="space-y-1.5">
          <div className="w-full h-5 bg-slate-100 rounded-full overflow-hidden flex shadow-inner p-0.5">
            {/* 1. YO = MERAH (#D92D32) */}
            <div
              style={{ width: `${yoPct}%`, backgroundColor: '#D92D32' }}
              className="h-full transition-all duration-500 rounded-l-full"
              title={`YO (Merah): ${totalYO} btl (${yoPct}%)`}
            />
            {/* 2. OM = ORANYE (#F28C28) */}
            <div
              style={{ width: `${omPct}%`, backgroundColor: '#F28C28' }}
              className="h-full transition-all duration-500"
              title={`OM (Oranye): ${totalOM} btl (${omPct}%)`}
            />
            {/* 3. OS = PINK (#E875A9) */}
            <div
              style={{ width: `${osPct}%`, backgroundColor: '#E875A9' }}
              className="h-full transition-all duration-500"
              title={`OS (Pink): ${totalOS} btl (${osPct}%)`}
            />
            {/* 4. YT = BIRU (#2689D8) */}
            <div
              style={{ width: `${ytPct}%`, backgroundColor: '#2689D8' }}
              className="h-full transition-all duration-500 rounded-r-full"
              title={`YT (Biru): ${totalYT} btl (${ytPct}%)`}
            />
          </div>
          <p className="text-[10px] text-slate-400 text-center font-medium">
            Proporsi visual penjualan 4 varian Yakult
          </p>
        </div>

        {/* 4 Cards Detail per Varian dengan Warna Tetap */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          {/* YO = MERAH (#D92D32) */}
          <div
            style={{ borderColor: '#D92D32' }}
            className="p-2.5 rounded-xl border-2 bg-red-50/40 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YO" size="sm" />
              <span className="text-[11px] font-black text-[#D92D32]">{yoPct}%</span>
            </div>
            <p className="text-base font-black text-[#D92D32] leading-tight">
              {totalYO} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] text-slate-600 font-semibold">Yakult Original</p>
          </div>

          {/* OM = ORANYE (#F28C28) */}
          <div
            style={{ borderColor: '#F28C28' }}
            className="p-2.5 rounded-xl border-2 bg-orange-50/40 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OM" size="sm" />
              <span className="text-[11px] font-black text-[#F28C28]">{omPct}%</span>
            </div>
            <p className="text-base font-black text-[#F28C28] leading-tight">
              {totalOM} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] text-slate-600 font-semibold">Yakult Mangga</p>
          </div>

          {/* OS = PINK (#E875A9) */}
          <div
            style={{ borderColor: '#E875A9' }}
            className="p-2.5 rounded-xl border-2 bg-pink-50/40 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OS" size="sm" />
              <span className="text-[11px] font-black text-[#E875A9]">{osPct}%</span>
            </div>
            <p className="text-base font-black text-[#E875A9] leading-tight">
              {totalOS} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] text-slate-600 font-semibold">Yakult Strawberry</p>
          </div>

          {/* YT = BIRU (#2689D8) */}
          <div
            style={{ borderColor: '#2689D8' }}
            className="p-2.5 rounded-xl border-2 bg-sky-50/40 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YT" size="sm" />
              <span className="text-[11px] font-black text-[#2689D8]">{ytPct}%</span>
            </div>
            <p className="text-base font-black text-[#2689D8] leading-tight">
              {totalYT} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] text-slate-600 font-semibold">Yakult Light</p>
          </div>
        </div>
      </div>

      {/* Chart 2: Komparasi Kinerja 7 Yakult Lady dengan Rincian 4 Varian */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-800">
              Kinerja 7 Yakult Lady per Varian
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-medium">Satuan: Botol</span>
        </div>

        <div className="space-y-3.5 pt-1">
          {memberPerformances.map((perf, index) => {
            const barWidth = Math.max(8, Math.round((perf.sold / maxSold) * 100));
            const isTop = index === 0 && perf.sold > 0;

            const yoWidth = perf.sold > 0 ? (perf.mYO / perf.sold) * 100 : 50;
            const omWidth = perf.sold > 0 ? (perf.mOM / perf.sold) * 100 : 25;
            const osWidth = perf.sold > 0 ? (perf.mOS / perf.sold) * 100 : 15;
            const ytWidth = perf.sold > 0 ? (perf.mYT / perf.sold) * 100 : 10;

            return (
              <div key={perf.memberId} className="space-y-1.5 p-2.5 bg-slate-50/60 rounded-xl border border-slate-200/70">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="w-6 text-slate-400 font-mono font-bold">{perf.code}</span>
                    <span className="font-bold text-slate-800">{perf.name}</span>
                    {isTop && (
                      <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                        <Award className="w-2.5 h-2.5" /> Peringkat 1
                      </span>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="font-black text-slate-800 text-sm">{perf.sold}</span>
                    <span className="text-slate-400 text-[10px] ml-1">/ {perf.dropping} btl</span>
                  </div>
                </div>

                {/* Multi-segment variant bar for this YL */}
                <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden flex shadow-inner">
                  <div style={{ width: `${yoWidth}%`, backgroundColor: '#D92D32' }} title={`YO: ${perf.mYO}`} />
                  <div style={{ width: `${omWidth}%`, backgroundColor: '#F28C28' }} title={`OM: ${perf.mOM}`} />
                  <div style={{ width: `${osWidth}%`, backgroundColor: '#E875A9' }} title={`OS: ${perf.mOS}`} />
                  <div style={{ width: `${ytWidth}%`, backgroundColor: '#2689D8' }} title={`YT: ${perf.mYT}`} />
                </div>

                {/* Variant Breakdown Badges */}
                <div className="flex items-center justify-between text-[10px] pt-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-[#D92D32]">YO: {perf.mYO}</span>
                    <span className="text-slate-300">&bull;</span>
                    <span className="font-bold text-[#F28C28]">OM: {perf.mOM}</span>
                    <span className="text-slate-300">&bull;</span>
                    <span className="font-bold text-[#E875A9]">OS: {perf.mOS}</span>
                    <span className="text-slate-300">&bull;</span>
                    <span className="font-bold text-[#2689D8]">YT: {perf.mYT}</span>
                  </div>
                  <span className="font-bold text-emerald-700">Efisiensi: {perf.efficiency}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
