import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Customer } from '../../types';
import {
  saveCustomer,
  subscribeCustomers,
  deleteCustomer,
} from '../../firebase/service';
import { DEMO_CUSTOMERS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import {
  Users,
  UserPlus,
  Phone,
  MessageSquare,
  MapPin,
  Calendar,
  Search,
  Trash2,
  CheckCircle2,
  Save,
  X,
  Store,
  Home,
  Building2,
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [targetMemberId, setTargetMemberId] = useState<string>(activeMember.memberId);
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [routeArea, setRouteArea] = useState(activeMember.routeArea);
  const [deliveryDays, setDeliveryDays] = useState('Senin, Rabu, Jumat');
  const [regularBottleCount, setRegularBottleCount] = useState<number>(5);
  const [customerType, setCustomerType] = useState<Customer['customerType']>('Rumah Tangga');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setTargetMemberId(activeMember.memberId);
    setRouteArea(activeMember.routeArea);
  }, [activeMember.memberId, activeMember.routeArea]);

  useEffect(() => {
    const unsub = subscribeCustomers(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setCustomers(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_CUSTOMERS
            : DEMO_CUSTOMERS.filter((c) => c.memberId === activeMember.memberId);
          setCustomers(filtered);
        } else {
          setCustomers([]);
        }
      }
    );
    return () => unsub();
  }, [activeMember.memberId, isAdmin, useDemoData]);

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const selectedMember =
        allMembers.find((m) => m.memberId === targetMemberId) || activeMember;

      await saveCustomer({
        memberId: selectedMember.memberId,
        memberName: selectedMember.name,
        customerName: customerName.trim(),
        phone: phone.trim(),
        address: address.trim(),
        routeArea: routeArea.trim() || selectedMember.routeArea,
        deliveryDays,
        regularBottleCount: Number(regularBottleCount),
        customerType,
        notes: notes.trim(),
        isDemo: false,
      });

      setIsModalOpen(false);
      // Reset
      setCustomerName('');
      setPhone('');
      setAddress('');
      setNotes('');
      alert('Pelanggan berhasil disimpan ke Cloud Firestore!');
    } catch (err: any) {
      alert('Gagal menyimpan: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, isDemo?: boolean) => {
    if (isDemo) {
      alert('Item contoh DEMO tidak dapat dihapus.');
      return;
    }
    if (window.confirm('Yakin ingin menghapus data pelanggan ini?')) {
      try {
        await deleteCustomer(id);
      } catch (err: any) {
        alert('Gagal menghapus: ' + err.message);
      }
    }
  };

  // Filter customers by search
  const filteredCustomers = customers.filter(
    (c) =>
      c.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.routeArea.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-700" />
            Data Pelanggan Rute
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar pelanggan tetap, rute pengantaran, dan jadwal rutin Yakult Lady
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Tambah</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          placeholder="Cari nama pelanggan, alamat, atau rute area..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-white text-xs pl-10 pr-4 py-2.5 rounded-xl border border-slate-200/90 shadow-xs focus:outline-emerald-600"
        />
      </div>

      {/* Customer List */}
      <div className="space-y-3">
        {filteredCustomers.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-2">
            <Users className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">Tidak ada data pelanggan ditemukan</p>
            <p className="text-xs text-slate-500">
              Klik tombol "Tambah" di atas untuk mendaftarkan pelanggan rute baru.
            </p>
          </div>
        ) : (
          filteredCustomers.map((cust) => (
            <div
              key={cust.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-2.5"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-slate-800">{cust.customerName}</h3>
                    <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.2 rounded-full">
                      {cust.customerType}
                    </span>
                    {cust.isDemo && <DemoBadge isDemo={true} />}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                    <span>{cust.address}</span>
                  </p>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-black text-emerald-900 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                    {cust.regularBottleCount} btl/antar
                  </span>
                  <p className="text-[10px] text-slate-500 mt-0.5">{cust.memberName}</p>
                </div>
              </div>

              {/* Delivery Days & Area */}
              <div className="flex items-center gap-3 text-xs text-slate-600 pt-1 border-t border-slate-100">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  Jadwal: <b>{cust.deliveryDays}</b>
                </span>
                <span>&bull;</span>
                <span>Area: <b>{cust.routeArea}</b></span>
              </div>

              {cust.notes && (
                <p className="text-xs text-slate-600 italic bg-slate-50 p-2 rounded-lg">
                  "{cust.notes}"
                </p>
              )}

              {/* Action Buttons: Phone, WhatsApp, Delete */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  {cust.phone && (
                    <>
                      <a
                        href={`https://wa.me/${cust.phone.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </a>
                      <a
                        href={`tel:${cust.phone}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5 text-slate-500" />
                        <span>{cust.phone}</span>
                      </a>
                    </>
                  )}
                </div>

                {(isAdmin || !cust.isDemo) && (
                  <button
                    onClick={() => handleDelete(cust.id, cust.isDemo)}
                    className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg transition-colors cursor-pointer"
                    title="Hapus Pelanggan"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Tambah Pelanggan */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl p-4 space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-base text-slate-800 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-700" />
                Tambah Pelanggan Rute Baru
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Petugas Yakult Lady Penanggung Jawab
                </label>
                {isAdmin ? (
                  <select
                    value={targetMemberId}
                    onChange={(e) => setTargetMemberId(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-xl font-semibold bg-white"
                  >
                    {allMembers
                      .filter((m) => m.role === 'yl')
                      .map((m) => (
                        <option key={m.memberId} value={m.memberId}>
                          {m.code} - {m.name}
                        </option>
                      ))}
                  </select>
                ) : (
                  <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800">
                    {activeMember.name} ({activeMember.code})
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nama Pelanggan / Toko
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Ibu Rahayu / Toko Barokah"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  required
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Nomor HP / WhatsApp
                  </label>
                  <input
                    type="tel"
                    placeholder="081234567xxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Jenis Pelanggan
                  </label>
                  <select
                    value={customerType}
                    onChange={(e) => setCustomerType(e.target.value as any)}
                    className="w-full p-2.5 border border-slate-300 rounded-xl font-semibold bg-white"
                  >
                    <option value="Rumah Tangga">Rumah Tangga</option>
                    <option value="Toko/Warung">Toko/Warung</option>
                    <option value="Kantor">Kantor</option>
                    <option value="Sekolah">Sekolah</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Alamat Lengkap Pengantaran
                </label>
                <input
                  type="text"
                  placeholder="Jl. Melati No. 12, Kel. Kaliwates..."
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  className="w-full p-2.5 border border-slate-300 rounded-xl font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Jadwal Hari Antar
                  </label>
                  <input
                    type="text"
                    value={deliveryDays}
                    onChange={(e) => setDeliveryDays(e.target.value)}
                    placeholder="Senin, Kamis"
                    className="w-full p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Jumlah Botol per Antar
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={regularBottleCount}
                    onChange={(e) =>
                      setRegularBottleCount(Math.max(1, parseInt(e.target.value) || 1))
                    }
                    className="w-full p-2.5 border border-slate-300 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Catatan Pengantaran Khusus
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Taruh di kulkas / bayar mingguan setiap Sabtu..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Menyimpan...' : 'Simpan Data Pelanggan'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
