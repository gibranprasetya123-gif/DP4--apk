import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DailyInput } from '../../types';
import { saveDailyInput, subscribeDailyInputs, deleteDailyInput } from '../../firebase/service';
import { DEMO_DAILY_INPUTS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS } from '../../data/productVariants';
import {
  ClipboardPenLine,
  History,
  CheckCircle2,
  Trash2,
  AlertCircle,
  Calendar,
  Save,
  RotateCcw,
  Sparkles,
  Info,
  Package,
} from 'lucide-react';

export const DailyInputView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');

  // Form State
  const [targetMemberId, setTargetMemberId] = useState<string>(activeMember.memberId);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [droppingStock, setDroppingStock] = useState<number>(250);

  // 4 Varian Produk Yakult
  // 1. YO = MERAH (#D92D32)
  // 2. OM = ORANYE (#F28C28)
  // 3. OS = PINK (#E875A9)
  // 4. YT = BIRU (#2689D8)
  const [soldYO, setSoldYO] = useState<number>(140);
  const [soldOM, setSoldOM] = useState<number>(40);
  const [soldOS, setSoldOS] = useState<number>(25);
  const [soldYT, setSoldYT] = useState<number>(20);

  const [brokenStock, setBrokenStock] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');

  const PRICE_PER_BOTTLE = 2500; // Harga patokan eceran resmi Yakult Rp 2.500
  const totalSold =
    (Number(soldYO) || 0) +
    (Number(soldOM) || 0) +
    (Number(soldOS) || 0) +
    (Number(soldYT) || 0);

  const calculatedReturnStock = Math.max(
    0,
    (Number(droppingStock) || 0) - totalSold - (Number(brokenStock) || 0)
  );
  const [customCashDeposit, setCustomCashDeposit] = useState<number>(totalSold * PRICE_PER_BOTTLE);

  // Status feedback
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // History State
  const [historyList, setHistoryList] = useState<DailyInput[]>([]);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'mine'>('all');

  // Sync member when activeMember changes
  useEffect(() => {
    setTargetMemberId(activeMember.memberId);
  }, [activeMember.memberId]);

  // Recalculate cash deposit when sales count changes
  useEffect(() => {
    setCustomCashDeposit(totalSold * PRICE_PER_BOTTLE);
  }, [totalSold]);

  // Subscribe to real-time daily inputs (Item 6: Anggota bisa melihat transaksi seluruh anggota)
  useEffect(() => {
    const unsub = subscribeDailyInputs(
      null, // Fetch all transactions so members can see team performance
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setHistoryList(data);
        } else if (useDemoData) {
          setHistoryList(DEMO_DAILY_INPUTS);
        } else {
          setHistoryList([]);
        }
      }
    );
    return () => unsub();
  }, [isAdmin, useDemoData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMessage(null);
    setSaveSuccess(false);

    try {
      const selectedMember = allMembers.find((m) => m.memberId === targetMemberId) || activeMember;

      const numYO = Number(soldYO) || 0;
      const numOM = Number(soldOM) || 0;
      const numOS = Number(soldOS) || 0;
      const numYT = Number(soldYT) || 0;

      await saveDailyInput({
        memberId: selectedMember.memberId,
        memberName: selectedMember.name,
        date,
        droppingStock: Number(droppingStock),
        soldYO: numYO,
        soldOM: numOM,
        soldOS: numOS,
        soldYT: numYT,
        soldRegular: numYO + numOM, // backward-compatibility
        soldLight: numOS + numYT, // backward-compatibility
        returnStock: calculatedReturnStock,
        brokenStock: Number(brokenStock),
        cashDeposit: Number(customCashDeposit),
        notes: notes.trim(),
        isDemo: false,
      });

      setSaveSuccess(true);
      setNotes('');
      setTimeout(() => {
        setSaveSuccess(false);
        setActiveTab('history');
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Gagal menyimpan transaksi ke Cloud Firestore.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, isDemoItem?: boolean) => {
    if (isDemoItem) {
      alert('Item contoh DEMO tidak dapat dihapus permanen dari Firestore.');
      return;
    }
    if (window.confirm('Yakin ingin menghapus data input harian ini? (Hak Admin)')) {
      try {
        await deleteDailyInput(id);
      } catch (err: any) {
        alert('Gagal menghapus: ' + err.message);
      }
    }
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* View Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <ClipboardPenLine className="w-5 h-5 text-emerald-700" />
            Input Harian Dropping
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan real-time 4 varian Yakult: YO, OM, OS, YT
          </p>
        </div>

        {/* Tab switcher buttons */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('form')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'form'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Form Input
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Riwayat
          </button>
        </div>
      </div>

      {/* Tab 1: Form Input */}
      {activeTab === 'form' && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 space-y-4">
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Data input harian berhasil disimpan ke Cloud Firestore! Mengalihkan...</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-300 text-red-800 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Member & Date Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Petugas Yakult Lady
              </label>
              {isAdmin ? (
                <select
                  value={targetMemberId}
                  onChange={(e) => setTargetMemberId(e.target.value)}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white focus:outline-emerald-600"
                >
                  {allMembers
                    .filter((m) => m.role === 'yl')
                    .map((m) => (
                      <option key={m.memberId} value={m.memberId}>
                        {m.code} - {m.name} ({m.routeArea})
                      </option>
                    ))}
                </select>
              ) : (
                <div className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 flex items-center justify-between">
                  <span>{activeMember.name}</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                    {activeMember.code}
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Tanggal Dropping
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white focus:outline-emerald-600"
                />
              </div>
            </div>
          </div>

          {/* Stok Dropping & Rusak */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Stok Dropping Awal
              </label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  value={droppingStock}
                  onChange={(e) => setDroppingStock(Math.max(0, parseInt(e.target.value) || 0))}
                  required
                  className="w-full text-base font-extrabold p-1.5 rounded-lg border border-slate-300 bg-white text-right"
                />
                <span className="text-xs text-slate-500 font-medium">btl</span>
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Botol Rusak / Pecah
              </label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  value={brokenStock}
                  onChange={(e) => setBrokenStock(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-base font-extrabold p-1.5 rounded-lg border border-slate-300 bg-white text-right text-red-700"
                />
                <span className="text-xs text-slate-500 font-medium">btl</span>
              </div>
            </div>
          </div>

          {/* 4 PRODUCT VARIANTS INPUT GRID */}
          <div className="border-t border-slate-100 pt-3 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Package className="w-4 h-4 text-emerald-700" />
                Penjualan 4 Varian Yakult
              </h3>
              <span className="text-[11px] text-slate-500">Warna Resmi & Identitas Tetap</span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {/* 1. YO = MERAH (#D92D32) */}
              <div
                style={{ borderColor: '#D92D32' }}
                className="bg-red-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="YO" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Original</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    value={soldYO}
                    onChange={(e) => setSoldYO(Math.max(0, parseInt(e.target.value) || 0))}
                    required
                    style={{ borderColor: '#D92D32', color: '#D92D32' }}
                    className="w-full text-base font-black p-1.5 rounded-lg border-2 bg-white text-right"
                  />
                  <span className="text-xs font-bold text-slate-500">btl</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">Warna: Merah (#D92D32)</p>
              </div>

              {/* 2. OM = ORANYE (#F28C28) */}
              <div
                style={{ borderColor: '#F28C28' }}
                className="bg-orange-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="OM" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Mangga</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    value={soldOM}
                    onChange={(e) => setSoldOM(Math.max(0, parseInt(e.target.value) || 0))}
                    required
                    style={{ borderColor: '#F28C28', color: '#F28C28' }}
                    className="w-full text-base font-black p-1.5 rounded-lg border-2 bg-white text-right"
                  />
                  <span className="text-xs font-bold text-slate-500">btl</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">Warna: Oranye (#F28C28)</p>
              </div>

              {/* 3. OS = PINK (#E875A9) */}
              <div
                style={{ borderColor: '#E875A9' }}
                className="bg-pink-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="OS" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Strawberry</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    value={soldOS}
                    onChange={(e) => setSoldOS(Math.max(0, parseInt(e.target.value) || 0))}
                    required
                    style={{ borderColor: '#E875A9', color: '#E875A9' }}
                    className="w-full text-base font-black p-1.5 rounded-lg border-2 bg-white text-right"
                  />
                  <span className="text-xs font-bold text-slate-500">btl</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">Warna: Pink (#E875A9)</p>
              </div>

              {/* 4. YT = BIRU (#2689D8) */}
              <div
                style={{ borderColor: '#2689D8' }}
                className="bg-sky-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="YT" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Light</span>
                </div>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    value={soldYT}
                    onChange={(e) => setSoldYT(Math.max(0, parseInt(e.target.value) || 0))}
                    required
                    style={{ borderColor: '#2689D8', color: '#2689D8' }}
                    className="w-full text-base font-black p-1.5 rounded-lg border-2 bg-white text-right"
                  />
                  <span className="text-xs font-bold text-slate-500">btl</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">Warna: Biru (#2689D8)</p>
              </div>
            </div>
          </div>

          {/* Automatic Calculation Card */}
          <div className="p-3.5 bg-linear-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-xl border border-emerald-300 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-slate-600">Total Terjual (4 Varian): </span>
              <b className="text-emerald-900 text-sm font-black">{totalSold} botol</b>
              <span className="mx-2 text-slate-300">|</span>
              <span className="text-slate-600">Sisa Kembali: </span>
              <b className="text-slate-800 font-bold">{calculatedReturnStock} botol</b>
            </div>
            <div>
              <span className="text-slate-600">Estimasi Setoran (@Rp2.500): </span>
              <b className="text-emerald-900 text-sm font-black">
                {formatRupiah(totalSold * PRICE_PER_BOTTLE)}
              </b>
            </div>
          </div>

          {/* Financials & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Uang Setoran Kas (Rupiah)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">Rp</span>
                <input
                  type="number"
                  min="0"
                  value={customCashDeposit}
                  onChange={(e) => setCustomCashDeposit(Math.max(0, parseInt(e.target.value) || 0))}
                  required
                  className="w-full text-sm font-bold pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                Dapat disesuaikan bila terdapat potongan kupon atau pembayaran tempo.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Catatan Operasional / Pelanggan
              </label>
              <input
                type="text"
                placeholder="Contoh: Rute lancar, penambahan varian mangga di toko Bu Sri..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                maxLength={500}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 bg-emerald-800 hover:bg-emerald-700 active:scale-98 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {saving ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Menyimpan ke Cloud Firestore...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Simpan Transaksi Harian</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Riwayat Input Harian */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {/* Filter Bar: Semua Anggota vs Milik Saya */}
          <div className="flex items-center justify-between gap-2 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setHistoryFilter('all')}
              className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                historyFilter === 'all'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua Anggota (DP JBR 4)
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('mine')}
              className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                historyFilter === 'mine'
                  ? 'bg-white text-emerald-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Transaksi Saya ({activeMember.code})
            </button>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600 px-1">
            <span>
              Menampilkan <b>{historyList.filter((item) => historyFilter === 'all' || item.memberId === activeMember.memberId).length}</b> transaksi
            </span>
            <span className="text-[11px] text-slate-500">
              {isAdmin ? 'Mode Admin (Akses Penuh)' : 'Bisa melihat semua, edit hanya milik sendiri'}
            </span>
          </div>

          {historyList.filter((item) => historyFilter === 'all' || item.memberId === activeMember.memberId).length === 0 ? (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-2">
              <ClipboardPenLine className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">Belum ada riwayat transaksi</p>
              <p className="text-xs text-slate-500">
                Gunakan tab "Form Input" untuk menambahkan data transaksi dropping harian pertama Anda.
              </p>
              <button
                onClick={() => setActiveTab('form')}
                className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-800 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Isi Input Harian Sekarang
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {historyList
                .filter((item) => historyFilter === 'all' || item.memberId === activeMember.memberId)
                .map((item) => {
                  const isOwner = item.memberId === activeMember.memberId;
                  const canEdit = isAdmin || isOwner;

                  // 4 Variants breakdown
                  const yoCount = item.soldYO ?? (item.soldRegular ? Math.round(item.soldRegular * 0.75) : 0);
                  const omCount = item.soldOM ?? (item.soldRegular ? item.soldRegular - yoCount : 0);
                  const osCount = item.soldOS ?? (item.soldLight ? Math.round(item.soldLight * 0.55) : 0);
                  const ytCount = item.soldYT ?? (item.soldLight ? item.soldLight - osCount : 0);
                  const totalItemSold = (item.soldRegular || 0) + (item.soldLight || 0);

                  return (
                    <div
                      key={item.id}
                      className="bg-white p-3.5 rounded-xl border border-slate-200/90 shadow-xs space-y-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-800 text-sm">{item.memberName}</span>
                          <span className="text-[11px] text-slate-500 font-mono">
                            {new Date(item.date).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            })}
                          </span>
                          {item.isDemo && <DemoBadge isDemo={true} />}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-black text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                            {formatRupiah(item.cashDeposit)}
                          </span>

                          {/* Tombol Edit: Hanya untuk pemilik data atau Admin */}
                          {canEdit && (
                            <button
                              onClick={() => {
                                setTargetMemberId(item.memberId);
                                setDate(item.date);
                                setDroppingStock(item.droppingStock);
                                setSoldYO(yoCount);
                                setSoldOM(omCount);
                                setSoldOS(osCount);
                                setSoldYT(ytCount);
                                setBrokenStock(item.brokenStock || 0);
                                setCustomCashDeposit(item.cashDeposit);
                                setNotes(item.notes || '');
                                setActiveTab('form');
                              }}
                              className="text-slate-500 hover:text-emerald-700 p-1 rounded-md transition-colors cursor-pointer text-xs font-semibold flex items-center gap-0.5"
                              title="Edit transaksi ini"
                            >
                              Edit
                            </button>
                          )}

                          {/* Tombol Hapus: HANYA untuk Admin (Aturan 8: Anggota tidak bisa menghapus) */}
                          {isAdmin ? (
                            <button
                              onClick={() => handleDelete(item.id, item.isDemo)}
                              className="text-slate-400 hover:text-red-600 p-1 rounded-md transition-colors cursor-pointer"
                              title="Hapus data ini (Hak Khusus Admin)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          ) : null}
                        </div>
                      </div>

                      {/* 4 VARIAN KONSISTEN BADGES & COUNTS */}
                      <div className="grid grid-cols-4 gap-1.5 pt-0.5">
                        <div className="bg-red-50/80 p-1.5 rounded-lg border border-[#D92D32]/40 text-center">
                          <ProductBadge code="YO" size="sm" />
                          <p className="font-extrabold text-[#D92D32] text-xs mt-1">{yoCount} btl</p>
                        </div>
                        <div className="bg-orange-50/80 p-1.5 rounded-lg border border-[#F28C28]/40 text-center">
                          <ProductBadge code="OM" size="sm" />
                          <p className="font-extrabold text-[#F28C28] text-xs mt-1">{omCount} btl</p>
                        </div>
                        <div className="bg-pink-50/80 p-1.5 rounded-lg border border-[#E875A9]/40 text-center">
                          <ProductBadge code="OS" size="sm" />
                          <p className="font-extrabold text-[#E875A9] text-xs mt-1">{osCount} btl</p>
                        </div>
                        <div className="bg-sky-50/80 p-1.5 rounded-lg border border-[#2689D8]/40 text-center">
                          <ProductBadge code="YT" size="sm" />
                          <p className="font-extrabold text-[#2689D8] text-xs mt-1">{ytCount} btl</p>
                        </div>
                      </div>

                      {/* Stock Summary Footer */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500 bg-slate-50 px-2 py-1 rounded-lg">
                        <span>Drop: <b>{item.droppingStock} btl</b></span>
                        <span>Total Terjual: <b className="text-emerald-800">{totalItemSold} btl</b></span>
                        <span>Sisa: <b>{item.returnStock} btl</b></span>
                        {item.brokenStock ? (
                          <span className="text-red-600">Rusak: {item.brokenStock}</span>
                        ) : null}
                      </div>

                      {item.notes && (
                        <p className="text-xs text-slate-600 italic bg-slate-50/50 p-1.5 rounded-md">
                          "{item.notes}"
                        </p>
                      )}
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
