import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DailyInput, TargetYL, MenuId } from '../../types';
import { subscribeDailyInputs, subscribeTargets } from '../../firebase/service';
import { DEMO_DAILY_INPUTS, DEMO_TARGETS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS } from '../../data/productVariants';
import {
  TrendingUp,
  PackageCheck,
  Banknote,
  Percent,
  PlusCircle,
  Users,
  Target,
  ArrowUpRight,
  ShieldCheck,
  Calendar,
  Sparkles,
  Package,
  ClipboardList,
  RotateCcw,
} from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (menu: MenuId) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [dailyInputs, setDailyInputs] = useState<DailyInput[]>([]);
  const [targets, setTargets] = useState<TargetYL[]>([]);

  // Subscribe to Firestore data
  useEffect(() => {
    const unsubInputs = subscribeDailyInputs(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setDailyInputs(data);
        } else if (useDemoData) {
          // If Firestore is empty and demo mode is active, use filtered demo data
          const filtered = isAdmin
            ? DEMO_DAILY_INPUTS
            : DEMO_DAILY_INPUTS.filter((d) => d.memberId === activeMember.memberId);
          setDailyInputs(filtered);
        } else {
          setDailyInputs([]);
        }
      }
    );

    const unsubTargets = subscribeTargets((data) => {
      if (data.length > 0) {
        setTargets(data);
      } else if (useDemoData) {
        setTargets(DEMO_TARGETS);
      }
    });

    return () => {
      unsubInputs();
      unsubTargets();
    };
  }, [activeMember.memberId, isAdmin, useDemoData]);

  // Aggregate metrics
  const totalDropping = dailyInputs.reduce((sum, item) => sum + (item.droppingStock || 0), 0);
  const totalRegular = dailyInputs.reduce((sum, item) => sum + (item.soldRegular || 0), 0);
  const totalLight = dailyInputs.reduce((sum, item) => sum + (item.soldLight || 0), 0);

  // 4 Varian Produk Yakult
  // 1. YO = MERAH (#D92D32)
  // 2. OM = ORANYE (#F28C28)
  // 3. OS = PINK (#E875A9)
  // 4. YT = BIRU (#2689D8)
  const totalYO = dailyInputs.reduce(
    (sum, item) =>
      sum + (item.soldYO ?? (item.soldRegular ? Math.round(item.soldRegular * 0.75) : 0)),
    0
  );
  const totalOM = dailyInputs.reduce(
    (sum, item) =>
      sum +
      (item.soldOM ??
        (item.soldRegular ? item.soldRegular - Math.round(item.soldRegular * 0.75) : 0)),
    0
  );
  const totalOS = dailyInputs.reduce(
    (sum, item) =>
      sum + (item.soldOS ?? (item.soldLight ? Math.round(item.soldLight * 0.55) : 0)),
    0
  );
  const totalYT = dailyInputs.reduce(
    (sum, item) =>
      sum +
      (item.soldYT ??
        (item.soldLight ? item.soldLight - Math.round(item.soldLight * 0.55) : 0)),
    0
  );

  const totalSold = totalYO + totalOM + totalOS + totalYT || (totalRegular + totalLight);
  const totalDeposit = dailyInputs.reduce((sum, item) => sum + (item.cashDeposit || 0), 0);
  const totalBroken = dailyInputs.reduce((sum, item) => sum + (item.brokenStock || 0), 0);
  const salesEfficiency = totalDropping > 0 ? Math.round((totalSold / totalDropping) * 100) : 0;

  // Active target for current user or DP total
  const currentTarget = targets.find((t) => t.memberId === activeMember.memberId);
  const dailyTargetCount = currentTarget?.dailyBottleTarget || (isAdmin ? 1465 : 210);
  const targetPercent = dailyTargetCount > 0 ? Math.min(100, Math.round((totalSold / dailyTargetCount) * 100)) : 0;

  // Format IDR Currency
  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const isPreviewDemo = useDemoData && dailyInputs.some((d) => d.isDemo);

  return (
    <div className="space-y-4 pb-20">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 rounded-2xl p-4 text-white shadow-md relative overflow-hidden">
        {/* Abstract decor */}
        <div className="absolute right-0 -bottom-6 w-32 h-32 bg-white/5 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-start justify-between relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-semibold bg-emerald-700/80 text-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date().toLocaleDateString('id-ID', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                })}
              </span>
              {isPreviewDemo && <DemoBadge isDemo={true} />}
            </div>
            <h1 className="text-xl font-extrabold tracking-tight">
              Halo, {activeMember.name}
            </h1>
            <p className="text-xs text-emerald-100 mt-0.5">
              {isAdmin
                ? 'Monitoring Seluruh Kinerja 7 Yakult Lady DP Jember 4'
                : `Wilayah Rute: ${activeMember.routeArea}`}
            </p>
          </div>

          <button
            onClick={() => onNavigate('input_harian')}
            className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs px-3 py-2 rounded-xl shadow-md transition-all cursor-pointer shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Input Harian</span>
          </button>
        </div>

        {/* Target Progress Bar */}
        <div className="mt-4 pt-3 border-t border-emerald-700/70">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-emerald-200 font-medium">
              Capaian Target Hari Ini: <b className="text-white">{totalSold}</b> / {dailyTargetCount} botol
            </span>
            <span className="font-bold text-white bg-emerald-700/80 px-2 py-0.5 rounded-md">
              {targetPercent}%
            </span>
          </div>
          <div className="w-full h-2.5 bg-emerald-950/60 rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-linear-to-r from-amber-400 to-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(targetPercent, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* KPI Cards Grid (4 Mobile Cards) */}
      <div className="grid grid-cols-2 gap-3">
        {/* KPI 1: Botol Terjual */}
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-slate-600">Total Terjual</span>
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <PackageCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-800 tracking-tight">
            {totalSold.toLocaleString('id-ID')}
            <span className="text-xs font-normal text-slate-500 ml-1">btl</span>
          </div>
          <div className="mt-1 flex items-center gap-1 flex-wrap">
            <ProductBadge code="YO" count={totalYO} size="sm" />
            <ProductBadge code="OM" count={totalOM} size="sm" />
            <ProductBadge code="OS" count={totalOS} size="sm" />
            <ProductBadge code="YT" count={totalYT} size="sm" />
          </div>
        </div>

        {/* KPI 2: Stok Dropping */}
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-slate-600">Stok Dropping</span>
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-700">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-800 tracking-tight">
            {totalDropping.toLocaleString('id-ID')}
            <span className="text-xs font-normal text-slate-500 ml-1">btl</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500 font-medium">
            Sisa: {Math.max(0, totalDropping - totalSold - totalBroken)} btl
          </div>
        </div>

        {/* KPI 3: Setoran Kas */}
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-slate-600">Setoran Kas</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <Banknote className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg font-black text-slate-800 tracking-tight truncate">
            {formatRupiah(totalDeposit)}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 font-medium">
            Kas masuk hari ini
          </div>
        </div>

        {/* KPI 4: Efisiensi Penjualan */}
        <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-slate-600">Efisiensi</span>
            <div className="p-1.5 rounded-lg bg-purple-50 text-purple-700">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-800 tracking-tight">
            {salesEfficiency}%
          </div>
          <div className="mt-1 text-[11px] text-emerald-700 font-semibold">
            {salesEfficiency >= 90 ? 'Sangat Baik' : salesEfficiency >= 80 ? 'Optimal' : 'Perlu Dorongan'}
          </div>
        </div>
      </div>

      {/* 4 VARIAN YAKULT COLOR IDENTITIES CARD */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Package className="w-4 h-4 text-emerald-700" />
            Realisasi Penjualan 4 Varian Yakult
          </h3>
          <span className="text-[10px] text-slate-500 font-semibold">4 Varian Resmi</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* YO = MERAH (#D92D32) */}
          <div
            style={{ borderColor: '#D92D32' }}
            className="p-2.5 rounded-xl border-2 bg-red-50/40 space-y-1 shadow-2xs"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YO" size="sm" />
              <span className="text-[10px] font-bold text-slate-500">
                {totalSold > 0 ? Math.round((totalYO / totalSold) * 100) : 0}%
              </span>
            </div>
            <p className="text-lg font-black text-[#D92D32] leading-none pt-0.5">
              {totalYO} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] font-semibold text-slate-600">Yakult Original</p>
          </div>

          {/* OM = ORANYE (#F28C28) */}
          <div
            style={{ borderColor: '#F28C28' }}
            className="p-2.5 rounded-xl border-2 bg-orange-50/40 space-y-1 shadow-2xs"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OM" size="sm" />
              <span className="text-[10px] font-bold text-slate-500">
                {totalSold > 0 ? Math.round((totalOM / totalSold) * 100) : 0}%
              </span>
            </div>
            <p className="text-lg font-black text-[#F28C28] leading-none pt-0.5">
              {totalOM} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] font-semibold text-slate-600">Yakult Mangga</p>
          </div>

          {/* OS = PINK (#E875A9) */}
          <div
            style={{ borderColor: '#E875A9' }}
            className="p-2.5 rounded-xl border-2 bg-pink-50/40 space-y-1 shadow-2xs"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OS" size="sm" />
              <span className="text-[10px] font-bold text-slate-500">
                {totalSold > 0 ? Math.round((totalOS / totalSold) * 100) : 0}%
              </span>
            </div>
            <p className="text-lg font-black text-[#E875A9] leading-none pt-0.5">
              {totalOS} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] font-semibold text-slate-600">Yakult Strawberry</p>
          </div>

          {/* YT = BIRU (#2689D8) */}
          <div
            style={{ borderColor: '#2689D8' }}
            className="p-2.5 rounded-xl border-2 bg-sky-50/40 space-y-1 shadow-2xs"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YT" size="sm" />
              <span className="text-[10px] font-bold text-slate-500">
                {totalSold > 0 ? Math.round((totalYT / totalSold) * 100) : 0}%
              </span>
            </div>
            <p className="text-lg font-black text-[#2689D8] leading-none pt-0.5">
              {totalYT} <span className="text-xs font-normal text-slate-500">btl</span>
            </p>
            <p className="text-[10px] font-semibold text-slate-600">Yakult Light</p>
          </div>
        </div>
      </div>

      {/* Quick Action Shortcuts */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5">
          Akses Cepat Menu
        </h3>
        <div className="grid grid-cols-4 gap-2 text-center">
          <button
            onClick={() => onNavigate('input_harian')}
            className="flex flex-col items-center p-2 rounded-xl bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center mb-1">
              <PlusCircle className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold leading-tight">Input</span>
          </button>

          <button
            onClick={() => onNavigate('pdm')}
            className="flex flex-col items-center p-2 rounded-xl bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center mb-1">
              <ClipboardList className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold leading-tight">PDM</span>
          </button>

          <button
            onClick={() => onNavigate('kembali_botol')}
            className="flex flex-col items-center p-2 rounded-xl bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-800 flex items-center justify-center mb-1">
              <RotateCcw className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold leading-tight">Kembali</span>
          </button>

          <button
            onClick={() => onNavigate('ringkasan')}
            className="flex flex-col items-center p-2 rounded-xl bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center mb-1">
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold leading-tight">Rekap</span>
          </button>
        </div>
      </div>

      {/* Admin View: Monitoring 7 Yakult Lady Performance */}
      {isAdmin && (
        <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <h3 className="font-bold text-slate-800 text-sm">Monitoring 7 Yakult Lady Hari Ini</h3>
            </div>
            <button
              onClick={() => onNavigate('ringkasan')}
              className="text-xs text-emerald-700 font-semibold hover:underline cursor-pointer"
            >
              Lihat Detail &rarr;
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {allMembers
              .filter((m) => m.role === 'yl')
              .map((member) => {
                const memberInput = dailyInputs.find((d) => d.memberId === member.memberId);
                const sold = (memberInput?.soldRegular || 0) + (memberInput?.soldLight || 0);
                const drop = memberInput?.droppingStock || 0;
                const eff = drop > 0 ? Math.round((sold / drop) * 100) : 0;

                return (
                  <div
                    key={member.memberId}
                    className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0">
                        {member.code.replace('YL-', '')}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="font-bold text-xs text-slate-800 truncate">{member.name}</p>
                          <span className="text-[10px] text-slate-400 font-medium">({member.code})</span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">{member.routeArea}</p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-bold text-xs text-slate-800">
                        {sold > 0 ? `${sold} btl` : <span className="text-slate-400">Belum input</span>}
                      </div>
                      {sold > 0 && (
                        <div className="flex items-center gap-1 justify-end mt-1">
                          <ProductBadge code="YO" count={memberInput?.soldYO ?? Math.round((memberInput?.soldRegular || 0) * 0.75)} size="sm" />
                          <ProductBadge code="OM" count={memberInput?.soldOM ?? Math.round((memberInput?.soldRegular || 0) * 0.25)} size="sm" />
                          <ProductBadge code="OS" count={memberInput?.soldOS ?? Math.round((memberInput?.soldLight || 0) * 0.55)} size="sm" />
                          <ProductBadge code="YT" count={memberInput?.soldYT ?? Math.round((memberInput?.soldLight || 0) * 0.45)} size="sm" />
                        </div>
                      )}
                      {drop > 0 && (
                        <div className="text-[10px] text-emerald-700 font-medium mt-0.5">
                          Efisiensi {eff}%
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Yakult Lady View: Catatan Khusus Profil Sendiri */}
      {!isAdmin && (
        <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-sm">Status Rute Anda Hari Ini</h3>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
              {activeMember.code}
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs text-slate-600">
            <p>
              <strong className="text-slate-800">Wilayah Rute:</strong> {activeMember.routeArea}
            </p>
            <p>
              <strong className="text-slate-800">Kontak Terdaftar:</strong> {activeMember.phone}
            </p>
            <p>
              <strong className="text-slate-800">Status Operasional:</strong>{' '}
              <span className="text-emerald-700 font-bold">Aktif & Siap Dropping</span>
            </p>
          </div>
          <button
            onClick={() => onNavigate('input_harian')}
            className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" /> Masukkan Laporan Dropping Hari Ini
          </button>
        </div>
      )}
    </div>
  );
};
