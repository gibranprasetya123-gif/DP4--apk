import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Member } from '../../types';
import {
  ContactRound,
  ShieldCheck,
  User,
  Phone,
  MessageSquare,
  MapPin,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Database,
} from 'lucide-react';

export const MembersView: React.FC = () => {
  const { allMembers, activeMember, switchActiveMember, seedInitialMembersToFirestore, isOnline } =
    useAuth();
  const [syncing, setSyncing] = useState(false);

  const handleSyncFirestore = async () => {
    setSyncing(true);
    try {
      await seedInitialMembersToFirestore();
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <ContactRound className="w-5 h-5 text-emerald-700" />
            Data Anggota & Petugas
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar resmi 1 Admin Koordinator dan 7 Yakult Lady DP JBR 4
          </p>
        </div>

        <button
          onClick={handleSyncFirestore}
          disabled={syncing}
          className="flex items-center gap-1.5 px-3 py-2 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
          title="Sinkronisasi seluruh profil anggota ke Cloud Firestore"
        >
          <Database className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
          <span>{syncing ? 'Menyinkronkan...' : 'Sinkron Firestore'}</span>
        </button>
      </div>

      {/* Members Directory */}
      <div className="space-y-3">
        {allMembers.map((member) => {
          const isActive = activeMember.memberId === member.memberId;
          const isAdmin = member.role === 'admin';

          return (
            <div
              key={member.memberId}
              className={`bg-white rounded-2xl border p-4 shadow-xs transition-all space-y-3 ${
                isActive
                  ? 'border-emerald-500 ring-1 ring-emerald-400 bg-emerald-50/20'
                  : 'border-slate-200/90'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 shadow-xs ${
                      isAdmin
                        ? 'bg-purple-900 text-white'
                        : 'bg-emerald-800 text-white'
                    }`}
                  >
                    {isAdmin ? (
                      <ShieldCheck className="w-6 h-6" />
                    ) : (
                      member.code.replace('YL-', '')
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-sm text-slate-800">{member.name}</h3>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                          isAdmin
                            ? 'bg-purple-100 text-purple-800 border border-purple-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {member.code}
                      </span>
                      {isActive && (
                        <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.2 rounded-full">
                          Aktif
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>{member.routeArea}</span>
                    </p>
                  </div>
                </div>

                <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                  Status: {member.status === 'active' ? 'Aktif' : 'Non-aktif'}
                </span>
              </div>

              {/* Actions: Hubungi WA, Telepon, Switch profile */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  {member.phone && (
                    <>
                      <a
                        href={`https://wa.me/${member.phone.replace(/[^0-9]/g, '').replace(/^0/, '62')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </a>
                      <a
                        href={`tel:${member.phone}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5 text-slate-500" />
                        <span>{member.phone}</span>
                      </a>
                    </>
                  )}
                </div>

                {!isActive && (
                  <button
                    onClick={() => switchActiveMember(member.memberId)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    Gunakan Profil Ini
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
