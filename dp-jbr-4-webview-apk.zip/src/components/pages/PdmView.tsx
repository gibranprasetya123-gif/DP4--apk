import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PdmRecord } from '../../types';
import {
  savePdmRecord,
  deletePdmRecord,
  subscribePdmRecords,
} from '../../firebase/service';
import { DEMO_PDM_RECORDS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS, PRODUCT_LIST } from '../../data/productVariants';
import {
  ClipboardList,
  PlusCircle,
  Save,
  Trash2,
  Edit3,
  Calendar,
  User,
  Package,
  Layers,
  History,
  AlertCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

export const PdmView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();

  // Form State
  const [selectedMemberId, setSelectedMemberId] = useState<string>(activeMember.memberId);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [pdmYO, setPdmYO] = useState<number>(0);
  const [pdmOM, setPdmOM] = useState<number>(0);
  const [pdmOS, setPdmOS] = useState<number>(0);
  const [pdmYT, setPdmYT] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Data & Filter State
  const [pdmList, setPdmList] = useState<PdmRecord[]>([]);
  const [filterDate, setFilterDate] = useState<string>('');
  const [filterMemberId, setFilterMemberId] = useState<string>(
    isAdmin ? 'all' : activeMember.memberId
  );
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');
  const [saving, setSaving] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Sync selectedMemberId if active user changes and not editing
  useEffect(() => {
    if (!editingId && !isAdmin) {
      setSelectedMemberId(activeMember.memberId);
    }
  }, [activeMember.memberId, isAdmin, editingId]);

  // Real-time listener from Firestore
  useEffect(() => {
    const unsub = subscribePdmRecords(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setPdmList(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_PDM_RECORDS
            : DEMO_PDM_RECORDS.filter((r) => r.memberId === activeMember.memberId);
          setPdmList(filtered);
        } else {
          setPdmList([]);
        }
      }
    );

    return () => unsub();
  }, [isAdmin, activeMember.memberId, useDemoData]);

  // Total PDM Botol otomatis
  const totalPDM = (pdmYO || 0) + (pdmOM || 0) + (pdmOS || 0) + (pdmYT || 0);

  // Quick fill preset for Requirement G test case
  const handleLoadTestCase = () => {
    setPdmYO(100);
    setPdmOM(80);
    setPdmOS(50);
    setPdmYT(30);
    setNotes('Kasus Uji Validasi PDM: YO 100, OM 80, OS 50, YT 30 (Total 260)');
    setStatusMessage('Data Kasus Uji Validasi (YO 100, OM 80, OS 50, YT 30) telah dimuat!');
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleResetForm = () => {
    setEditingId(null);
    setPdmYO(0);
    setPdmOM(0);
    setPdmOS(0);
    setPdmYT(0);
    setNotes('');
    setDate(new Date().toISOString().slice(0, 10));
    if (!isAdmin) {
      setSelectedMemberId(activeMember.memberId);
    }
  };

  const handleEdit = (record: PdmRecord) => {
    setEditingId(record.id);
    setSelectedMemberId(record.memberId);
    setDate(record.date);
    setPdmYO(record.pdmYO || 0);
    setPdmOM(record.pdmOM || 0);
    setPdmOS(record.pdmOS || 0);
    setPdmYT(record.pdmYT || 0);
    setNotes(record.notes || '');
    setActiveTab('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    if (!isAdmin) {
      alert('Hanya Admin yang memiliki hak akses menghapus data PDM.');
      return;
    }
    if (confirm('Yakin ingin menghapus data PDM ini?')) {
      try {
        await deletePdmRecord(id);
        setStatusMessage('Data PDM berhasil dihapus dari Cloud Firestore!');
        setTimeout(() => setStatusMessage(null), 3000);
      } catch (err: any) {
        alert('Gagal menghapus data: ' + err.message);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (totalPDM <= 0) {
      alert('Mohon isi minimal salah satu varian botol PDM (> 0).');
      return;
    }

    const memberObj = allMembers.find((m) => m.memberId === selectedMemberId);
    const memberName = memberObj ? memberObj.name : activeMember.name;

    setSaving(true);
    try {
      await savePdmRecord({
        id: editingId || undefined,
        memberId: selectedMemberId,
        memberName,
        date,
        pdmYO,
        pdmOM,
        pdmOS,
        pdmYT,
        totalPDM,
        notes: notes.trim(),
        isDemo: false,
      });

      setStatusMessage(
        editingId
          ? 'Perubahan PDM berhasil diperbarui di Firestore!'
          : 'Data PDM berhasil disimpan ke Firestore! Perhitungan Kembali Botol langsung terhubung.'
      );
      handleResetForm();
      setActiveTab('history');
      setTimeout(() => setStatusMessage(null), 4000);
    } catch (err: any) {
      alert('Gagal menyimpan PDM: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  // Filtered history list
  const filteredList = pdmList.filter((item) => {
    if (filterMemberId !== 'all' && item.memberId !== filterMemberId) return false;
    if (filterDate && item.date !== filterDate) return false;
    return true;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
                <ClipboardList className="w-5 h-5" />
              </span>
              <h2 className="text-lg font-extrabold text-slate-800">
                Pesanan Di Muka (PDM)
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Input pesanan di muka 4 varian produk Yakult per anggota & tanggal
            </p>
          </div>

          {useDemoData && pdmList.some((p) => p.isDemo) && <DemoBadge isDemo={true} />}
        </div>

        {/* 4 Variant Legend */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-bold text-slate-400 mr-0.5">Varian:</span>
          {PRODUCT_LIST.map((p) => (
            <div
              key={p.code}
              style={{ borderColor: p.hex }}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border bg-white text-[11px]"
            >
              <ProductBadge code={p.code} size="sm" />
              <span className="font-semibold text-slate-700">{p.name}</span>
            </div>
          ))}
        </div>

        {/* Tab Selector */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold">
          <button
            onClick={() => setActiveTab('form')}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'form'
                ? 'bg-white text-emerald-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>{editingId ? 'Edit PDM' : 'Input PDM Baru'}</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'history'
                ? 'bg-white text-emerald-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Riwayat PDM ({filteredList.length})</span>
          </button>
        </div>
      </div>

      {/* Success / Status Notification */}
      {statusMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-semibold">{statusMessage}</span>
        </div>
      )}

      {/* TAB 1: FORM INPUT PDM */}
      {activeTab === 'form' && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
            <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-700" />
              <span>{editingId ? 'Ubah Transaksi PDM' : 'Form Pencatatan PDM'}</span>
            </h3>

            {/* Quick Test Preset Button */}
            <button
              type="button"
              onClick={handleLoadTestCase}
              className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
              title="Isi kasus uji: YO 100, OM 80, OS 50, YT 30"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Muat Kasus Uji (60 Botol)</span>
            </button>
          </div>

          {/* Member & Date Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-500" />
                Nama Yakult Lady
              </label>
              {isAdmin ? (
                <select
                  value={selectedMemberId}
                  onChange={(e) => setSelectedMemberId(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold bg-white focus:ring-2 focus:ring-emerald-700"
                >
                  {allMembers
                    .filter((m) => m.role === 'yl')
                    .map((m) => (
                      <option key={m.memberId} value={m.memberId}>
                        {m.name} ({m.code})
                      </option>
                    ))}
                </select>
              ) : (
                <div className="p-2 border border-slate-200 rounded-xl bg-slate-50 text-xs font-bold text-slate-800">
                  {activeMember.name} ({activeMember.code})
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Tanggal PDM
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold bg-white focus:ring-2 focus:ring-emerald-700"
              />
            </div>
          </div>

          {/* 4 PRODUCT VARIANTS INPUT GRID WITH FIXED COLOR IDENTITY */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wide">
                Jumlah Botol PDM per Varian:
              </label>
              <span className="text-[11px] text-slate-500">
                Warna Tetap (YO, OM, OS, YT)
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {/* 1. YO = MERAH (#D92D32) */}
              <div
                style={{ borderColor: PRODUCT_VARIANTS.YO.hex }}
                className="bg-red-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="YO" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Original</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    value={pdmYO === 0 ? '' : pdmYO}
                    onChange={(e) => setPdmYO(Math.max(0, parseInt(e.target.value) || 0))}
                    placeholder="0"
                    className="w-full text-base font-black p-1.5 rounded-lg border border-slate-300 bg-white text-right focus:outline-hidden"
                  />
                  <span className="text-xs text-slate-500 font-semibold">btl</span>
                </div>
              </div>

              {/* 2. OM = ORANYE (#F28C28) */}
              <div
                style={{ borderColor: PRODUCT_VARIANTS.OM.hex }}
                className="bg-orange-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="OM" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Mangga</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    value={pdmOM === 0 ? '' : pdmOM}
                    onChange={(e) => setPdmOM(Math.max(0, parseInt(e.target.value) || 0))}
                    placeholder="0"
                    className="w-full text-base font-black p-1.5 rounded-lg border border-slate-300 bg-white text-right focus:outline-hidden"
                  />
                  <span className="text-xs text-slate-500 font-semibold">btl</span>
                </div>
              </div>

              {/* 3. OS = PINK (#E875A9) */}
              <div
                style={{ borderColor: PRODUCT_VARIANTS.OS.hex }}
                className="bg-pink-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="OS" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Strawberry</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    value={pdmOS === 0 ? '' : pdmOS}
                    onChange={(e) => setPdmOS(Math.max(0, parseInt(e.target.value) || 0))}
                    placeholder="0"
                    className="w-full text-base font-black p-1.5 rounded-lg border border-slate-300 bg-white text-right focus:outline-hidden"
                  />
                  <span className="text-xs text-slate-500 font-semibold">btl</span>
                </div>
              </div>

              {/* 4. YT = BIRU (#2689D8) */}
              <div
                style={{ borderColor: PRODUCT_VARIANTS.YT.hex }}
                className="bg-sky-50/50 p-3 rounded-xl border-2 space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <ProductBadge code="YT" size="md" />
                  <span className="text-[11px] font-bold text-slate-600">Light</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    value={pdmYT === 0 ? '' : pdmYT}
                    onChange={(e) => setPdmYT(Math.max(0, parseInt(e.target.value) || 0))}
                    placeholder="0"
                    className="w-full text-base font-black p-1.5 rounded-lg border border-slate-300 bg-white text-right focus:outline-hidden"
                  />
                  <span className="text-xs text-slate-500 font-semibold">btl</span>
                </div>
              </div>
            </div>
          </div>

          {/* Total PDM Summary Strip */}
          <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between shadow-xs">
            <div>
              <p className="text-[10px] text-slate-400 font-semibold">TOTAL BOTOL PDM</p>
              <p className="text-xs text-slate-300">YO + OM + OS + YT</p>
            </div>
            <div className="text-right">
              <span className="text-xl font-black text-emerald-400">
                {totalPDM}
              </span>
              <span className="text-xs text-slate-300 ml-1">botol</span>
            </div>
          </div>

          {/* Notes field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Catatan PDM (Opsional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Pesanan tambahan warung bu Sri, langganan kantor..."
              maxLength={200}
              className="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-1">
            {editingId && (
              <button
                type="button"
                onClick={handleResetForm}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Batal
              </button>
            )}

            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-3 bg-emerald-800 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Menyimpan ke Firestore...' : editingId ? 'Simpan Perubahan PDM' : 'Simpan Data PDM'}</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: RIWAYAT INPUT PDM */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {/* Filter Bar */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-2xs space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {isAdmin && (
                <div>
                  <label className="block font-bold text-slate-600 mb-0.5">Filter Anggota</label>
                  <select
                    value={filterMemberId}
                    onChange={(e) => setFilterMemberId(e.target.value)}
                    className="w-full p-1.5 border border-slate-300 rounded-lg font-semibold bg-white"
                  >
                    <option value="all">Semua Yakult Lady (7 Anggota)</option>
                    {allMembers
                      .filter((m) => m.role === 'yl')
                      .map((m) => (
                        <option key={m.memberId} value={m.memberId}>
                          {m.name}
                        </option>
                      ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-600 mb-0.5">Filter Tanggal</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="date"
                    value={filterDate}
                    onChange={(e) => setFilterDate(e.target.value)}
                    className="w-full p-1.5 border border-slate-300 rounded-lg font-semibold bg-white text-xs"
                  />
                  {filterDate && (
                    <button
                      onClick={() => setFilterDate('')}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-bold"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* List of PDM Records */}
          {filteredList.length === 0 ? (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-2">
              <ClipboardList className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">Belum ada catatan PDM</p>
              <p className="text-xs text-slate-500">
                Silakan input pesanan di muka melalui tab &quot;Input PDM Baru&quot;.
              </p>
            </div>
          ) : (
            filteredList.map((item) => {
              const canEdit = isAdmin || item.memberId === activeMember.memberId;

              return (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-3.5 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-slate-800">
                          {item.memberName}
                        </span>
                        {item.isDemo && <DemoBadge isDemo={true} />}
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Tanggal: {item.date} &bull; Dropping JBR 4
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      {canEdit && (
                        <button
                          onClick={() => handleEdit(item)}
                          className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                          title="Ubah data PDM"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                      )}

                      {isAdmin && (
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 rounded-lg border border-red-200 hover:bg-red-50 text-red-600 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                          title="Hapus data PDM"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 4 Variant breakdown badges */}
                  <div className="grid grid-cols-4 gap-1.5 pt-1">
                    <div
                      style={{ borderColor: PRODUCT_VARIANTS.YO.hex }}
                      className="p-1.5 rounded-lg border bg-red-50/50 text-center"
                    >
                      <ProductBadge code="YO" size="sm" />
                      <p className="font-black text-xs text-slate-800 mt-1">
                        {item.pdmYO || 0}
                      </p>
                      <p className="text-[9px] text-slate-400">botol</p>
                    </div>

                    <div
                      style={{ borderColor: PRODUCT_VARIANTS.OM.hex }}
                      className="p-1.5 rounded-lg border bg-orange-50/50 text-center"
                    >
                      <ProductBadge code="OM" size="sm" />
                      <p className="font-black text-xs text-slate-800 mt-1">
                        {item.pdmOM || 0}
                      </p>
                      <p className="text-[9px] text-slate-400">botol</p>
                    </div>

                    <div
                      style={{ borderColor: PRODUCT_VARIANTS.OS.hex }}
                      className="p-1.5 rounded-lg border bg-pink-50/50 text-center"
                    >
                      <ProductBadge code="OS" size="sm" />
                      <p className="font-black text-xs text-slate-800 mt-1">
                        {item.pdmOS || 0}
                      </p>
                      <p className="text-[9px] text-slate-400">botol</p>
                    </div>

                    <div
                      style={{ borderColor: PRODUCT_VARIANTS.YT.hex }}
                      className="p-1.5 rounded-lg border bg-sky-50/50 text-center"
                    >
                      <ProductBadge code="YT" size="sm" />
                      <p className="font-black text-xs text-slate-800 mt-1">
                        {item.pdmYT || 0}
                      </p>
                      <p className="text-[9px] text-slate-400">botol</p>
                    </div>
                  </div>

                  {/* Total & Notes Strip */}
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                    <div className="text-[11px] text-slate-500 truncate max-w-[200px]">
                      {item.notes ? item.notes : 'Tidak ada catatan'}
                    </div>
                    <div className="font-extrabold text-slate-800">
                      Total PDM:{' '}
                      <span className="text-emerald-700 font-black">
                        {item.totalPDM} botol
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
