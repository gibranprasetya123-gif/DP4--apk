import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PlasticsAndBottles } from '../../types';
import {
  savePlasticsAndBottles,
  subscribePlasticsAndBottles,
} from '../../firebase/service';
import { DEMO_PLASTICS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import {
  Package,
  Recycle,
  Save,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  History,
  ShieldCheck,
} from 'lucide-react';

export const PlasticsBottlesView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');

  // Form State
  const [targetMemberId, setTargetMemberId] = useState<string>(activeMember.memberId);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [smallPlastic, setSmallPlastic] = useState<number>(50);
  const [largePlastic, setLargePlastic] = useState<number>(20);
  const [coolerBagStatus, setCoolerBagStatus] = useState<string>('Kondisi Baik & Higienis');
  const [emptyBottles, setEmptyBottles] = useState<number>(140);
  const [cratesReceived, setCratesReceived] = useState<number>(5);
  const [cratesReturned, setCratesReturned] = useState<number>(5);
  const [notes, setNotes] = useState<string>('');

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [records, setRecords] = useState<PlasticsAndBottles[]>([]);

  useEffect(() => {
    setTargetMemberId(activeMember.memberId);
  }, [activeMember.memberId]);

  useEffect(() => {
    const unsub = subscribePlasticsAndBottles(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setRecords(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_PLASTICS
            : DEMO_PLASTICS.filter((d) => d.memberId === activeMember.memberId);
          setRecords(filtered);
        } else {
          setRecords([]);
        }
      }
    );
    return () => unsub();
  }, [activeMember.memberId, isAdmin, useDemoData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);

    try {
      const selectedMember =
        allMembers.find((m) => m.memberId === targetMemberId) || activeMember;

      await savePlasticsAndBottles({
        memberId: selectedMember.memberId,
        memberName: selectedMember.name,
        date,
        smallPlasticReceived: Number(smallPlastic),
        largePlasticReceived: Number(largePlastic),
        coolerBagStatus,
        emptyBottlesCollected: Number(emptyBottles),
        cratesReceived: Number(cratesReceived),
        cratesReturned: Number(cratesReturned),
        notes: notes.trim(),
        isDemo: false,
      });

      setSaveSuccess(true);
      setNotes('');
      setTimeout(() => {
        setSaveSuccess(false);
        setActiveTab('history');
      }, 1000);
    } catch (err: any) {
      alert('Gagal menyimpan: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-700" />
            Plastik dan Botol
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Administrasi kantong plastik, kondisi tas pendingin, botol kosong & krat
          </p>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('form')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'form'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600'
            }`}
          >
            Input Sarana
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600'
            }`}
          >
            Riwayat
          </button>
        </div>
      </div>

      {/* Tab 1: Form Input */}
      {activeTab === 'form' && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 space-y-3.5">
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Data sarana plastik & botol berhasil tersimpan ke Cloud Firestore!</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Petugas Yakult Lady
              </label>
              {isAdmin ? (
                <select
                  value={targetMemberId}
                  onChange={(e) => setTargetMemberId(e.target.value)}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  {allMembers
                    .filter((m) => m.role === 'yl')
                    .map((m) => (
                      <option key={m.memberId} value={m.memberId}>
                        {m.code} - {m.name}
                      </option>
                    ))}
                </select>
              ) : (
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 flex justify-between items-center">
                  <span>{activeMember.name}</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                    {activeMember.code}
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white"
              />
            </div>
          </div>

          {/* Sarana Plastik & Cooler Bag */}
          <div className="border-t border-slate-100 pt-3">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Kantong Plastik & Tas Pendingin
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Plastik Kecil Diterima
                </label>
                <input
                  type="number"
                  min="0"
                  value={smallPlastic}
                  onChange={(e) => setSmallPlastic(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Plastik Besar Diterima
                </label>
                <input
                  type="number"
                  min="0"
                  value={largePlastic}
                  onChange={(e) => setLargePlastic(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Kondisi Tas Pendingin (Cooler Bag)
                </label>
                <select
                  value={coolerBagStatus}
                  onChange={(e) => setCoolerBagStatus(e.target.value)}
                  className="w-full text-xs font-semibold p-2 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="Kondisi Baik & Higienis">Kondisi Baik & Higienis</option>
                  <option value="Perlu Dicuci / Servis">Perlu Dicuci / Servis</option>
                  <option value="Resleting / Tali Rusak">Resleting / Tali Rusak</option>
                  <option value="Perlu Penggantian Baru">Perlu Penggantian Baru</option>
                </select>
              </div>
            </div>
          </div>

          {/* Botol Kosong & Krat */}
          <div className="border-t border-slate-100 pt-3">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Botol Kosong Daur Ulang & Krat/Tray
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Botol Kosong Terkumpul
                </label>
                <input
                  type="number"
                  min="0"
                  value={emptyBottles}
                  onChange={(e) => setEmptyBottles(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Krat / Tray Diterima
                </label>
                <input
                  type="number"
                  min="0"
                  value={cratesReceived}
                  onChange={(e) => setCratesReceived(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Krat / Tray Dikembalikan
                </label>
                <input
                  type="number"
                  min="0"
                  value={cratesReturned}
                  onChange={(e) => setCratesReturned(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Catatan Sarana / Perlengkapan
            </label>
            <input
              type="text"
              placeholder="Catatan kebersihan cooler box atau kebutuhan kantong tambahan..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 bg-emerald-800 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Menyimpan...' : 'Simpan Data Plastik & Botol'}</span>
          </button>
        </form>
      )}

      {/* Tab 2: History List */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {records.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs">
              Belum ada pencatatan plastik & botol.
            </div>
          ) : (
            records.map((r) => (
              <div
                key={r.id}
                className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-3.5 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-800">{r.memberName}</span>
                    <span className="text-[11px] text-slate-500">{r.date}</span>
                    {r.isDemo && <DemoBadge isDemo={true} />}
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
                    {r.coolerBagStatus}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2 rounded-xl text-xs text-center">
                  <div>
                    <p className="text-[10px] text-slate-500">Kantong Plastik</p>
                    <p className="font-bold text-slate-700">
                      K: {r.smallPlasticReceived} | B: {r.largePlasticReceived}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500">Botol Kosong</p>
                    <p className="font-bold text-emerald-800">{r.emptyBottlesCollected} btl</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500">Krat Diterima/Kembali</p>
                    <p className="font-bold text-slate-700">
                      {r.cratesReceived} / {r.cratesReturned}
                    </p>
                  </div>
                </div>

                {r.notes && (
                  <p className="text-[11px] text-slate-600 italic">"{r.notes}"</p>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
