import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Propaganda } from '../../types';
import {
  savePropaganda,
  subscribePropaganda,
  deletePropaganda,
} from '../../firebase/service';
import { DEMO_PROPAGANDA } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import {
  Megaphone,
  PlusCircle,
  MapPin,
  Users,
  Award,
  Sparkles,
  Save,
  Trash2,
  CheckCircle2,
  HeartPulse,
} from 'lucide-react';

export const PropagandaView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [activeTab, setActiveTab] = useState<'form' | 'history'>('form');

  // Form State
  const [targetMemberId, setTargetMemberId] = useState<string>(activeMember.memberId);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [location, setLocation] = useState<string>('');
  const [topic, setTopic] = useState<string>(
    'Pentingnya Probiotik L. casei Shirota strain untuk Imunitas & Kesehatan Usus'
  );
  const [audienceCount, setAudienceCount] = useState<number>(25);
  const [sampleBottles, setSampleBottles] = useState<number>(15);
  const [brochures, setBrochures] = useState<number>(20);
  const [newProspects, setNewProspects] = useState<number>(5);
  const [notes, setNotes] = useState<string>('');

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [records, setRecords] = useState<Propaganda[]>([]);

  useEffect(() => {
    setTargetMemberId(activeMember.memberId);
  }, [activeMember.memberId]);

  useEffect(() => {
    const unsub = subscribePropaganda(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setRecords(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_PROPAGANDA
            : DEMO_PROPAGANDA.filter((p) => p.memberId === activeMember.memberId);
          setRecords(filtered);
        } else {
          setRecords([]);
        }
      }
    );
    return () => unsub();
  }, [activeMember.memberId, isAdmin, useDemoData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);

    try {
      const selectedMember =
        allMembers.find((m) => m.memberId === targetMemberId) || activeMember;

      await savePropaganda({
        memberId: selectedMember.memberId,
        memberName: selectedMember.name,
        date,
        location: location.trim(),
        topic: topic.trim(),
        audienceCount: Number(audienceCount),
        sampleBottlesGiven: Number(sampleBottles),
        brochuresGiven: Number(brochures),
        newProspectsCount: Number(newProspects),
        notes: notes.trim(),
        isDemo: false,
      });

      setSaveSuccess(true);
      setLocation('');
      setNotes('');
      setTimeout(() => {
        setSaveSuccess(false);
        setActiveTab('history');
      }, 1000);
    } catch (err: any) {
      alert('Gagal menyimpan: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, isDemo?: boolean) => {
    if (isDemo) {
      alert('Item contoh DEMO tidak dapat dihapus.');
      return;
    }
    if (window.confirm('Hapus dokumentasi propaganda ini?')) {
      try {
        await deletePropaganda(id);
      } catch (err: any) {
        alert('Gagal menghapus: ' + err.message);
      }
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-emerald-700" />
            Propaganda & Edukasi Kesehatan
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan kegiatan sosialisasi kesehatan pencernaan, sampling, & prospek pelanggan
          </p>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('form')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'form'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600'
            }`}
          >
            Form Edukasi
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-slate-600'
            }`}
          >
            Riwayat
          </button>
        </div>
      </div>

      {/* Tab 1: Form Propaganda */}
      {activeTab === 'form' && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 space-y-3.5">
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Dokumentasi propaganda berhasil disimpan ke Cloud Firestore!</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Petugas Yakult Lady
              </label>
              {isAdmin ? (
                <select
                  value={targetMemberId}
                  onChange={(e) => setTargetMemberId(e.target.value)}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  {allMembers
                    .filter((m) => m.role === 'yl')
                    .map((m) => (
                      <option key={m.memberId} value={m.memberId}>
                        {m.code} - {m.name}
                      </option>
                    ))}
                </select>
              ) : (
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 flex justify-between items-center">
                  <span>{activeMember.name}</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                    {activeMember.code}
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Kegiatan</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Lokasi / Komunitas Sasaran Edukasi
            </label>
            <input
              type="text"
              placeholder="Contoh: Posyandu Bougenville RW 05 Kaliwates / Pertemuan Ibu PKK"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Topik / Materi Propaganda
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          {/* Numbers: Peserta, Sample, Pamflet, Prospek */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Peserta Diedukasi
              </label>
              <input
                type="number"
                min="0"
                value={audienceCount}
                onChange={(e) => setAudienceCount(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full text-xs font-bold p-1.5 rounded-lg border border-slate-300 bg-white"
              />
            </div>

            <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200">
              <label className="block text-[11px] font-bold text-emerald-800 mb-1">
                Botol Sample Diberikan
              </label>
              <input
                type="number"
                min="0"
                value={sampleBottles}
                onChange={(e) => setSampleBottles(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full text-xs font-bold p-1.5 rounded-lg border border-emerald-300 bg-white"
              />
            </div>

            <div className="bg-blue-50/60 p-2.5 rounded-xl border border-blue-200">
              <label className="block text-[11px] font-bold text-blue-800 mb-1">
                Brosur / Pamflet
              </label>
              <input
                type="number"
                min="0"
                value={brochures}
                onChange={(e) => setBrochures(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full text-xs font-bold p-1.5 rounded-lg border border-blue-300 bg-white"
              />
            </div>

            <div className="bg-amber-50/60 p-2.5 rounded-xl border border-amber-200">
              <label className="block text-[11px] font-bold text-amber-800 mb-1">
                Prospek Berminat
              </label>
              <input
                type="number"
                min="0"
                value={newProspects}
                onChange={(e) => setNewProspects(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full text-xs font-bold p-1.5 rounded-lg border border-amber-300 bg-white text-amber-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Catatan Respon & Hasil Kegiatan
            </label>
            <input
              type="text"
              placeholder="Contoh: Peserta sangat tertarik bertanya waktu konsumsi Yakult terbaik..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 bg-emerald-800 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Menyimpan...' : 'Simpan Dokumentasi Propaganda'}</span>
          </button>
        </form>
      )}

      {/* Tab 2: Riwayat Propaganda */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {records.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs">
              Belum ada riwayat kegiatan propaganda.
            </div>
          ) : (
            records.map((r) => (
              <div
                key={r.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-2.5"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-sm text-slate-800">{r.location}</h3>
                      {r.isDemo && <DemoBadge isDemo={true} />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {r.memberName} &bull; Tanggal: {r.date}
                    </p>
                  </div>

                  {(isAdmin || !r.isDemo) && (
                    <button
                      onClick={() => handleDelete(r.id, r.isDemo)}
                      className="text-slate-400 hover:text-red-600 p-1 rounded-lg"
                      title="Hapus Catatan"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="text-xs text-slate-700 bg-slate-50 p-2 rounded-xl flex items-center gap-1.5 font-medium">
                  <HeartPulse className="w-4 h-4 text-red-600 shrink-0" />
                  <span>Topik: <b>{r.topic}</b></span>
                </div>

                <div className="grid grid-cols-4 gap-1.5 text-center text-xs bg-emerald-50/50 p-2 rounded-xl border border-emerald-100">
                  <div>
                    <p className="text-[10px] text-slate-500">Peserta</p>
                    <p className="font-extrabold text-slate-800">{r.audienceCount}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500">Sampling</p>
                    <p className="font-extrabold text-emerald-800">{r.sampleBottlesGiven} btl</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500">Brosur</p>
                    <p className="font-extrabold text-blue-800">{r.brochuresGiven}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500">Prospek</p>
                    <p className="font-extrabold text-amber-800">+{r.newProspectsCount}</p>
                  </div>
                </div>

                {r.notes && (
                  <p className="text-xs text-slate-600 italic">"{r.notes}"</p>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
