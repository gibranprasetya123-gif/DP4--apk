import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PdmRecord, DailyInput, ReturnBottleCalculation } from '../../types';
import { subscribePdmRecords, subscribeDailyInputs } from '../../firebase/service';
import { DEMO_PDM_RECORDS, DEMO_DAILY_INPUTS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS, PRODUCT_LIST } from '../../data/productVariants';
import {
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Calendar,
  Filter,
  Calculator,
  Layers,
  ArrowRight,
  TrendingDown,
  Info,
  Sparkles,
} from 'lucide-react';

export const ReturnBottlesView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [pdmList, setPdmList] = useState<PdmRecord[]>([]);
  const [dailyInputs, setDailyInputs] = useState<DailyInput[]>([]);
  const [filterMemberId, setFilterMemberId] = useState<string>(
    isAdmin ? 'all' : activeMember.memberId
  );
  const [filterDate, setFilterDate] = useState<string>('');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Real-time synchronization for PDM records
  useEffect(() => {
    const unsubPdm = subscribePdmRecords(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setPdmList(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_PDM_RECORDS
            : DEMO_PDM_RECORDS.filter((r) => r.memberId === activeMember.memberId);
          setPdmList(filtered);
        } else {
          setPdmList([]);
        }
      }
    );

    // Real-time synchronization for Daily Inputs
    const unsubInputs = subscribeDailyInputs(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setDailyInputs(data);
        } else if (useDemoData) {
          const filtered = isAdmin
            ? DEMO_DAILY_INPUTS
            : DEMO_DAILY_INPUTS.filter((d) => d.memberId === activeMember.memberId);
          setDailyInputs(filtered);
        } else {
          setDailyInputs([]);
        }
      }
    );

    return () => {
      unsubPdm();
      unsubInputs();
    };
  }, [isAdmin, activeMember.memberId, useDemoData]);

  // ENGINE PERHITUNGAN OTOMATIS: KEMBALI BOTOL = PDM - PENJUALAN
  // Dihitung per anggota (memberId), per tanggal (date), dan per varian produk (YO, OM, OS, YT)
  // Menjamin Aturan D1 (tidak manual), D2 (otomatis reaktif), D4 (tidak menolkan negatif),
  // D5 (tanpa dobel hitung via Map kunci unik), D7 (tanggal & anggota cocok)
  const returnCalculations = useMemo(() => {
    // Kumpulkan seluruh kombinasi unik (memberId, date) dari PDM dan DailyInput
    const keysMap = new Map<string, { memberId: string; date: string }>();

    pdmList.forEach((p) => {
      const key = `${p.memberId}_${p.date}`;
      if (!keysMap.has(key)) {
        keysMap.set(key, { memberId: p.memberId, date: p.date });
      }
    });

    dailyInputs.forEach((d) => {
      const key = `${d.memberId}_${d.date}`;
      if (!keysMap.has(key)) {
        keysMap.set(key, { memberId: d.memberId, date: d.date });
      }
    });

    const results: ReturnBottleCalculation[] = [];

    keysMap.forEach(({ memberId, date: itemDate }) => {
      // Ambil PDM dan DailyInput pada tanggal & anggota yang SAMA persis
      const pdm = pdmList.find((p) => p.memberId === memberId && p.date === itemDate);
      const input = dailyInputs.find((d) => d.memberId === memberId && d.date === itemDate);

      // PDM per varian
      const pYO = pdm ? pdm.pdmYO || 0 : 0;
      const pOM = pdm ? pdm.pdmOM || 0 : 0;
      const pOS = pdm ? pdm.pdmOS || 0 : 0;
      const pYT = pdm ? pdm.pdmYT || 0 : 0;
      const totalP = pdm ? pdm.totalPDM || pYO + pOM + pOS + pYT : 0;

      // Penjualan per varian (dengan backward-compatibility bila soldYO belum terisi)
      let sYO = 0;
      let sOM = 0;
      let sOS = 0;
      let sYT = 0;

      if (input) {
        sYO = input.soldYO ?? (input.soldRegular ? Math.round(input.soldRegular * 0.75) : 0);
        sOM =
          input.soldOM ??
          (input.soldRegular ? input.soldRegular - Math.round(input.soldRegular * 0.75) : 0);
        sOS = input.soldOS ?? (input.soldLight ? Math.round(input.soldLight * 0.5) : 0);
        sYT =
          input.soldYT ??
          (input.soldLight ? input.soldLight - Math.round(input.soldLight * 0.5) : 0);
      }

      const totalS = sYO + sOM + sOS + sYT;

      // Rumus: KEMBALI BOTOL = PDM - BOTOL TERJUAL
      // Aturan D4: Jangan mengubah hasil negatif menjadi nol!
      const retYO = pYO - sYO;
      const retOM = pOM - sOM;
      const retOS = pOS - sOS;
      const retYT = pYT - sYT;
      const totalR = retYO + retOM + retOS + retYT;

      // Aturan D3: Cek apakah ada selisih negatif (penjualan melebihi PDM)
      const hasNegative = retYO < 0 || retOM < 0 || retOS < 0 || retYT < 0 || totalR < 0;

      const memberObj = allMembers.find((m) => m.memberId === memberId);
      const memberName = memberObj ? memberObj.name : pdm?.memberName || input?.memberName || memberId;

      results.push({
        memberId,
        memberName,
        date: itemDate,
        pdmYO: pYO,
        soldYO: sYO,
        returnYO: retYO,
        pdmOM: pOM,
        soldOM: sOM,
        returnOM: retOM,
        pdmOS: pOS,
        soldOS: sOS,
        returnOS: retOS,
        pdmYT: pYT,
        soldYT: sYT,
        returnYT: retYT,
        totalPDM: totalP,
        totalSold: totalS,
        totalReturn: totalR,
        hasNegativeDiscrepancy: hasNegative,
        hasPdmRecord: !!pdm,
        hasDailyInput: !!input,
        pdmRecordId: pdm?.id,
        dailyInputId: input?.id,
      });
    });

    // Urutkan berdasarkan tanggal terbaru
    return results.sort((a, b) => b.date.localeCompare(a.date));
  }, [pdmList, dailyInputs, allMembers]);

  // Filter calculations based on UI selection
  const filteredCalculations = returnCalculations.filter((c) => {
    if (filterMemberId !== 'all' && c.memberId !== filterMemberId) return false;
    if (filterDate && c.date !== filterDate) return false;
    return true;
  });

  // Totals for all filtered calculations
  const grandTotals = filteredCalculations.reduce(
    (acc, curr) => {
      acc.pdmYO += curr.pdmYO;
      acc.soldYO += curr.soldYO;
      acc.returnYO += curr.returnYO;
      acc.pdmOM += curr.pdmOM;
      acc.soldOM += curr.soldOM;
      acc.returnOM += curr.returnOM;
      acc.pdmOS += curr.pdmOS;
      acc.soldOS += curr.soldOS;
      acc.returnOS += curr.returnOS;
      acc.pdmYT += curr.pdmYT;
      acc.soldYT += curr.soldYT;
      acc.returnYT += curr.returnYT;
      acc.totalPDM += curr.totalPDM;
      acc.totalSold += curr.totalSold;
      acc.totalReturn += curr.totalReturn;
      if (curr.hasNegativeDiscrepancy) acc.negativeCases++;
      return acc;
    },
    {
      pdmYO: 0,
      soldYO: 0,
      returnYO: 0,
      pdmOM: 0,
      soldOM: 0,
      returnOM: 0,
      pdmOS: 0,
      soldOS: 0,
      returnOS: 0,
      pdmYT: 0,
      soldYT: 0,
      returnYT: 0,
      totalPDM: 0,
      totalSold: 0,
      totalReturn: 0,
      negativeCases: 0,
    }
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
                <RotateCcw className="w-5 h-5" />
              </span>
              <h2 className="text-lg font-extrabold text-slate-800">
                Kembali Botol
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Rumus otomatis:{' '}
              <span className="font-extrabold text-emerald-800">
                KEMBALI BOTOL = PDM - BOTOL TERJUAL
              </span>
            </p>
          </div>

          {useDemoData && <DemoBadge isDemo={true} />}
        </div>

        {/* Protection Security Notice */}
        <div className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-700 flex items-center gap-2">
          <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
          <p className="text-[11px] leading-tight text-slate-600">
            <span className="font-bold text-slate-800">Perhitungan Terproteksi:</span>{' '}
            Hasil dihitung otomatis per anggota, tanggal, dan 4 varian produk. Tidak
            dapat dimanipulasi manual.
          </p>
        </div>

        {/* 4 Variant Color Legend */}
        <div className="pt-1 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-bold text-slate-400 mr-0.5">Varian:</span>
          {PRODUCT_LIST.map((p) => (
            <div
              key={p.code}
              style={{ borderColor: p.hex }}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border bg-white text-[11px]"
            >
              <ProductBadge code={p.code} size="sm" />
              <span className="font-semibold text-slate-700">{p.name}</span>
            </div>
          ))}
        </div>

        {/* View Mode & Filter Row */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
          <span className="text-xs font-bold text-slate-600">
            Total Rekap: {filteredCalculations.length} Transaksi
          </span>
          <div className="inline-flex p-0.5 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1 rounded-md font-bold transition-all ${
                viewMode === 'cards'
                  ? 'bg-white text-emerald-900 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Kartu Rincian
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-md font-bold transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-emerald-900 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Matriks Tabel
            </button>
          </div>
        </div>
      </div>

      {/* SPECIAL SYSTEM TEST BOX: KASUS UJI PERSYARATAN G (TOTAL 60 BOTOL) */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-4 rounded-2xl shadow-md space-y-3 border border-emerald-700/40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-emerald-500/20 rounded-lg text-emerald-300">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-extrabold text-sm text-emerald-200">
                Hasil Uji Sistem Sesuai Persyaratan G
              </h3>
              <p className="text-[11px] text-emerald-100/80">
                Uji: PDM - Penjualan per Varian (YO, OM, OS, YT)
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 bg-emerald-500 text-white text-[10px] font-black rounded-full uppercase tracking-wider">
            ✅ Valid 60 Botol
          </span>
        </div>

        {/* 4 Varian Formula Verification Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* YO */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.YO.hex }}
            className="bg-white/10 p-2.5 rounded-xl border border-red-400/50 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YO" size="sm" />
              <span className="text-[10px] text-red-200 font-bold">Original</span>
            </div>
            <p className="text-[11px] text-slate-300 font-mono">
              100 PDM &minus; 75 Jual
            </p>
            <div className="flex items-baseline justify-between pt-0.5 border-t border-white/10">
              <span className="text-[10px] text-slate-300">Kembali:</span>
              <span className="text-base font-black text-red-300">25 btl</span>
            </div>
          </div>

          {/* OM */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.OM.hex }}
            className="bg-white/10 p-2.5 rounded-xl border border-orange-400/50 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OM" size="sm" />
              <span className="text-[10px] text-orange-200 font-bold">Mangga</span>
            </div>
            <p className="text-[11px] text-slate-300 font-mono">
              80 PDM &minus; 60 Jual
            </p>
            <div className="flex items-baseline justify-between pt-0.5 border-t border-white/10">
              <span className="text-[10px] text-slate-300">Kembali:</span>
              <span className="text-base font-black text-orange-300">20 btl</span>
            </div>
          </div>

          {/* OS */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.OS.hex }}
            className="bg-white/10 p-2.5 rounded-xl border border-pink-400/50 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OS" size="sm" />
              <span className="text-[10px] text-pink-200 font-bold">Strawberry</span>
            </div>
            <p className="text-[11px] text-slate-300 font-mono">
              50 PDM &minus; 40 Jual
            </p>
            <div className="flex items-baseline justify-between pt-0.5 border-t border-white/10">
              <span className="text-[10px] text-slate-300">Kembali:</span>
              <span className="text-base font-black text-pink-300">10 btl</span>
            </div>
          </div>

          {/* YT */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.YT.hex }}
            className="bg-white/10 p-2.5 rounded-xl border border-sky-400/50 space-y-1"
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YT" size="sm" />
              <span className="text-[10px] text-sky-200 font-bold">Light</span>
            </div>
            <p className="text-[11px] text-slate-300 font-mono">
              30 PDM &minus; 25 Jual
            </p>
            <div className="flex items-baseline justify-between pt-0.5 border-t border-white/10">
              <span className="text-[10px] text-slate-300">Kembali:</span>
              <span className="text-base font-black text-sky-300">5 btl</span>
            </div>
          </div>
        </div>

        {/* Total Verification Proof Strip */}
        <div className="p-2.5 bg-black/40 rounded-xl flex items-center justify-between text-xs">
          <span className="text-slate-300 font-semibold">
            Total Kembali = 25 (YO) + 20 (OM) + 10 (OS) + 5 (YT):
          </span>
          <div className="flex items-center gap-1.5">
            <span className="text-lg font-black text-emerald-400">
              60 Botol
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-2xs space-y-2 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {isAdmin && (
            <div>
              <label className="block font-bold text-slate-600 mb-0.5">Filter Anggota</label>
              <select
                value={filterMemberId}
                onChange={(e) => setFilterMemberId(e.target.value)}
                className="w-full p-1.5 border border-slate-300 rounded-lg font-semibold bg-white"
              >
                <option value="all">Semua Yakult Lady ({allMembers.filter((m) => m.role === 'yl').length} Anggota)</option>
                {allMembers
                  .filter((m) => m.role === 'yl')
                  .map((m) => (
                    <option key={m.memberId} value={m.memberId}>
                      {m.name}
                    </option>
                  ))}
              </select>
            </div>
          )}

          <div>
            <label className="block font-bold text-slate-600 mb-0.5">Filter Tanggal</label>
            <div className="flex items-center gap-1.5">
              <input
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="w-full p-1.5 border border-slate-300 rounded-lg font-semibold bg-white text-xs"
              />
              {filterDate && (
                <button
                  onClick={() => setFilterDate('')}
                  className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-bold"
                >
                  Reset
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: DETAIL CARDS */}
      {viewMode === 'cards' && (
        <div className="space-y-3">
          {filteredCalculations.length === 0 ? (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-2">
              <RotateCcw className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">Belum Ada Data Terhitung</p>
              <p className="text-xs text-slate-500">
                Perhitungan Kembali Botol otomatis aktif saat data PDM dan Input Penjualan tersedia.
              </p>
            </div>
          ) : (
            filteredCalculations.map((calc) => {
              const variants = [
                {
                  ...PRODUCT_VARIANTS.YO,
                  pdm: calc.pdmYO,
                  sold: calc.soldYO,
                  ret: calc.returnYO,
                },
                {
                  ...PRODUCT_VARIANTS.OM,
                  pdm: calc.pdmOM,
                  sold: calc.soldOM,
                  ret: calc.returnOM,
                },
                {
                  ...PRODUCT_VARIANTS.OS,
                  pdm: calc.pdmOS,
                  sold: calc.soldOS,
                  ret: calc.returnOS,
                },
                {
                  ...PRODUCT_VARIANTS.YT,
                  pdm: calc.pdmYT,
                  sold: calc.soldYT,
                  ret: calc.returnYT,
                },
              ];

              return (
                <div
                  key={`${calc.memberId}_${calc.date}`}
                  className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3"
                >
                  {/* Card Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-black text-sm text-slate-800">
                        {calc.memberName}
                      </h3>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Tanggal: {calc.date} &bull; Dropping JBR 4
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {!calc.hasPdmRecord && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">
                          PDM Belum Diisi
                        </span>
                      )}
                      {!calc.hasDailyInput && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">
                          Penjualan Belum Diisi
                        </span>
                      )}
                      {calc.hasPdmRecord && calc.hasDailyInput && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Sinkron</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* NEGATIVE DISCREPANCY WARNING BANNER (ATURAN D3 & D4) */}
                  {calc.hasNegativeDiscrepancy && (
                    <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-red-700">
                        <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                        <span>PERINGATAN SELISIH NEGATIF:</span>
                      </div>
                      <p className="text-[11px] text-red-800">
                        Terdapat varian produk di mana penjualan melebihi PDM. Hasil negatif dipertahankan dan tidak diubah menjadi nol.
                      </p>
                    </div>
                  )}

                  {/* 4 VARIANTS CALCULATION BREAKDOWN */}
                  <div className="grid grid-cols-2 gap-2">
                    {variants.map((v) => {
                      const isNegative = v.ret < 0;

                      return (
                        <div
                          key={v.code}
                          style={{ borderColor: v.hex }}
                          className={`p-2.5 rounded-xl border space-y-1 shadow-2xs ${
                            isNegative ? 'bg-red-50/80 border-red-400' : 'bg-slate-50/70'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <ProductBadge code={v.code} size="sm" showName={true} />
                            {isNegative && (
                              <span className="px-1.5 py-0.2 rounded bg-red-600 text-white text-[9px] font-black">
                                SELISIH &minus;
                              </span>
                            )}
                          </div>

                          <div className="text-[10.5px] text-slate-500 font-mono flex items-center justify-between pt-0.5">
                            <span>PDM: {v.pdm}</span>
                            <span>Jual: {v.sold}</span>
                          </div>

                          <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
                            <span className="text-[10px] font-bold text-slate-600">
                              Kembali:
                            </span>
                            <span
                              className={`text-sm font-black font-mono ${
                                isNegative ? 'text-red-600' : 'text-slate-800'
                              }`}
                            >
                              {v.ret > 0 ? `+${v.ret}` : v.ret} btl
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Card Bottom Total Bar */}
                  <div className="p-2.5 bg-slate-900 text-white rounded-xl flex items-center justify-between text-xs">
                    <div className="space-y-0.5">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                        TOTAL KEMBALI BOTOL
                      </span>
                      <p className="text-[11px] text-slate-300 font-mono">
                        {calc.totalPDM} PDM &minus; {calc.totalSold} Penjualan
                      </p>
                    </div>

                    <div className="text-right">
                      <span
                        className={`text-lg font-black font-mono ${
                          calc.totalReturn < 0 ? 'text-red-400' : 'text-emerald-400'
                        }`}
                      >
                        {calc.totalReturn > 0 ? `+${calc.totalReturn}` : calc.totalReturn}
                      </span>
                      <span className="text-xs text-slate-300 ml-1">botol</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* VIEW MODE 2: MATRIKS TABEL LENGKAP */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-xs text-slate-800 uppercase tracking-wide">
                Matriks Kembali Botol (PDM &minus; Penjualan)
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Format per sel: PDM &minus; Terjual = Kembali
              </p>
            </div>
            {grandTotals.negativeCases > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[10px] font-bold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-red-600" />
                <span>{grandTotals.negativeCases} Kasus Selisih Negatif</span>
              </span>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100/90 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-2.5 whitespace-nowrap">Anggota & Tanggal</th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="YO" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.YO.hex }}>YO</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="OM" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.OM.hex }}>OM</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="OS" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.OS.hex }}>OS</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="YT" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.YT.hex }}>YT</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap font-black text-slate-900 bg-slate-200/60">
                    Total Kembali
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCalculations.map((calc) => (
                  <tr
                    key={`${calc.memberId}_${calc.date}`}
                    className="hover:bg-slate-50/70 transition-colors"
                  >
                    <td className="p-2.5 whitespace-nowrap">
                      <div className="font-bold text-slate-800">{calc.memberName}</div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        {calc.date}
                      </div>
                    </td>

                    {/* YO */}
                    <td className="p-2.5 text-center whitespace-nowrap">
                      <span
                        className={`font-black font-mono ${
                          calc.returnYO < 0 ? 'text-red-600' : 'text-slate-800'
                        }`}
                      >
                        {calc.returnYO}
                      </span>
                      <div className="text-[9px] text-slate-400">
                        {calc.pdmYO}&minus;{calc.soldYO}
                      </div>
                    </td>

                    {/* OM */}
                    <td className="p-2.5 text-center whitespace-nowrap">
                      <span
                        className={`font-black font-mono ${
                          calc.returnOM < 0 ? 'text-red-600' : 'text-slate-800'
                        }`}
                      >
                        {calc.returnOM}
                      </span>
                      <div className="text-[9px] text-slate-400">
                        {calc.pdmOM}&minus;{calc.soldOM}
                      </div>
                    </td>

                    {/* OS */}
                    <td className="p-2.5 text-center whitespace-nowrap">
                      <span
                        className={`font-black font-mono ${
                          calc.returnOS < 0 ? 'text-red-600' : 'text-slate-800'
                        }`}
                      >
                        {calc.returnOS}
                      </span>
                      <div className="text-[9px] text-slate-400">
                        {calc.pdmOS}&minus;{calc.soldOS}
                      </div>
                    </td>

                    {/* YT */}
                    <td className="p-2.5 text-center whitespace-nowrap">
                      <span
                        className={`font-black font-mono ${
                          calc.returnYT < 0 ? 'text-red-600' : 'text-slate-800'
                        }`}
                      >
                        {calc.returnYT}
                      </span>
                      <div className="text-[9px] text-slate-400">
                        {calc.pdmYT}&minus;{calc.soldYT}
                      </div>
                    </td>

                    {/* Total */}
                    <td className="p-2.5 text-center whitespace-nowrap font-black bg-slate-50">
                      <span
                        className={`font-mono text-sm ${
                          calc.totalReturn < 0 ? 'text-red-600' : 'text-emerald-800'
                        }`}
                      >
                        {calc.totalReturn}
                      </span>
                      <div className="text-[9px] text-slate-400">
                        {calc.totalPDM}&minus;{calc.totalSold}
                      </div>
                    </td>
                  </tr>
                ))}

                {/* Grand Total Row */}
                <tr className="bg-slate-100 font-extrabold text-slate-800 border-t-2 border-slate-300">
                  <td className="p-2.5">TOTAL DP JBR 4</td>
                  <td className="p-2.5 text-center font-mono font-black">
                    {grandTotals.returnYO}
                    <div className="text-[9px] font-normal text-slate-500">
                      {grandTotals.pdmYO}&minus;{grandTotals.soldYO}
                    </div>
                  </td>
                  <td className="p-2.5 text-center font-mono font-black">
                    {grandTotals.returnOM}
                    <div className="text-[9px] font-normal text-slate-500">
                      {grandTotals.pdmOM}&minus;{grandTotals.soldOM}
                    </div>
                  </td>
                  <td className="p-2.5 text-center font-mono font-black">
                    {grandTotals.returnOS}
                    <div className="text-[9px] font-normal text-slate-500">
                      {grandTotals.pdmOS}&minus;{grandTotals.soldOS}
                    </div>
                  </td>
                  <td className="p-2.5 text-center font-mono font-black">
                    {grandTotals.returnYT}
                    <div className="text-[9px] font-normal text-slate-500">
                      {grandTotals.pdmYT}&minus;{grandTotals.soldYT}
                    </div>
                  </td>
                  <td className="p-2.5 text-center font-mono font-black text-sm bg-emerald-100 text-emerald-900">
                    {grandTotals.totalReturn} btl
                    <div className="text-[9px] font-normal text-slate-600">
                      {grandTotals.totalPDM}&minus;{grandTotals.totalSold}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
