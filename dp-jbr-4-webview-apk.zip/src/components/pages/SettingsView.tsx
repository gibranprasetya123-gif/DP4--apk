import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Settings,
  Database,
  Shield,
  Wifi,
  WifiOff,
  User,
  Sparkles,
  RefreshCw,
  Info,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { DemoBadge } from '../common/DemoBadge';

export const SettingsView: React.FC = () => {
  const {
    user,
    activeMember,
    isAdmin,
    isOnline,
    useDemoData,
    setUseDemoData,
    seedInitialMembersToFirestore,
  } = useAuth();

  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  const handleSyncFirestore = async () => {
    setSyncing(true);
    setSyncMessage(null);
    try {
      await seedInitialMembersToFirestore();
      setSyncMessage('Berhasil mensinkronkan 7 profil Yakult Lady & Admin ke Cloud Firestore!');
    } catch (err: any) {
      setSyncMessage('Gagal: ' + err.message);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-700" />
          Pengaturan Aplikasi
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Status database Cloud Firestore, preferensi data demo, dan profil DP JBR 4
        </p>
      </div>

      {/* Profil Pengguna Aktif */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Profil Pengguna Aktif
        </h3>
        <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
          <div className="w-10 h-10 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-bold text-sm">
            {isAdmin ? 'ADM' : activeMember.code.replace('YL-', '')}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="font-extrabold text-sm text-slate-800">{activeMember.name}</p>
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.2 rounded-full">
                {activeMember.code}
              </span>
            </div>
            <p className="text-xs text-slate-500">{activeMember.routeArea}</p>
          </div>
          <span className="text-xs font-bold text-emerald-700">
            {isAdmin ? 'Admin' : 'Yakult Lady'}
          </span>
        </div>

        <div className="text-xs text-slate-600 space-y-1 pt-1">
          <p>
            <strong className="text-slate-700">Aturan Hak Akses: </strong>
            {isAdmin
              ? 'Admin dapat melihat dan mengelola seluruh data dari 7 Yakult Lady.'
              : 'Anggota Yakult Lady hanya dapat melihat dan mengelola data miliknya sendiri.'}
          </p>
        </div>
      </div>

      {/* Database & Cloud Firestore */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            <Database className="w-4 h-4 text-emerald-700" />
            Cloud Firestore & Firebase Auth
          </h3>
          <span
            className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full ${
              isOnline
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-red-100 text-red-800'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3 h-3 text-emerald-600" /> Terhubung Online
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-red-600" /> Mode Offline
              </>
            )}
          </span>
        </div>

        <p className="text-xs text-slate-600">
          Database utama dikonfigurasikan pada Google Cloud Firestore dengan database ID resmi:{' '}
          <code className="bg-slate-100 text-slate-800 px-1 py-0.5 rounded font-mono text-[11px]">
            ai-studio-b862670b-a242-496d-9e80-b9ba96416f65
          </code>
        </p>

        {syncMessage && (
          <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded-xl flex items-center gap-2 border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncMessage}</span>
          </div>
        )}

        <button
          onClick={handleSyncFirestore}
          disabled={syncing}
          className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
          <span>{syncing ? 'Menyinkronkan...' : 'Sinkronkan Daftar Anggota ke Cloud Firestore'}</span>
        </button>
      </div>

      {/* Mode Data Demo vs Real Firestore */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Mode Data Contoh (DEMO Preview)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Tampilkan data contoh berlabel DEMO saat database Firestore baru diinisialisasi
            </p>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={useDemoData}
              onChange={(e) => setUseDemoData(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl text-xs text-amber-900 space-y-1">
          <p className="font-semibold flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-amber-700" />
            Ketentuan Data:
          </p>
          <p>
            Sesuai aturan, data transaksi tidak dikarang. Seluruh data yang Anda masukkan via menu{' '}
            <b>Input Harian</b> akan langsung disimpan permanen di Cloud Firestore secara nyata.
          </p>
        </div>
      </div>

      {/* Informasi Sistem & Wilayah */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-2 text-xs text-slate-600">
        <h3 className="font-bold text-slate-800 text-sm">Informasi DP JBR 4</h3>
        <p>
          <strong>Nama Aplikasi:</strong> DP JBR 4 (Dropping Jember 4)
        </p>
        <p>
          <strong>Fungsi:</strong> Administrasi dan monitoring kinerja Yakult Lady
        </p>
        <p>
          <strong>Kapasitas Tim:</strong> 1 Admin Koordinator &bull; 7 Yakult Lady
        </p>
        <p>
          <strong>Wilayah Rute:</strong> Meliputi Kaliwates, Sumbersari, Patrang, Kebonsari, Mangli,
          Wirolegi, dan Kranjingan.
        </p>
        <p className="text-slate-400 text-[11px] pt-2 border-t border-slate-100">
          DP JBR 4 &bull; Versi 1.0.0 &bull; Dibangun dengan React + TypeScript + Cloud Firestore
        </p>
      </div>
    </div>
  );
};
