import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DailyInput, PdmRecord } from '../../types';
import { subscribeDailyInputs, subscribePdmRecords } from '../../firebase/service';
import { DEMO_DAILY_INPUTS, DEMO_PDM_RECORDS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import {
  FileSpreadsheet,
  Calendar,
  Filter,
  Download,
  Printer,
  ChevronDown,
  Layers,
  Banknote,
  TrendingUp,
  RotateCcw,
  Package,
  AlertTriangle,
  ClipboardList,
} from 'lucide-react';

import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_VARIANTS, PRODUCT_LIST } from '../../data/productVariants';

export const SummaryView: React.FC = () => {
  const { activeMember, isAdmin, allMembers, useDemoData } = useAuth();
  const [period, setPeriod] = useState<'harian' | 'mingguan' | 'bulanan'>('harian');
  const [selectedMemberId, setSelectedMemberId] = useState<string>(
    isAdmin ? 'all' : activeMember.memberId
  );
  const [inputs, setInputs] = useState<DailyInput[]>([]);
  const [pdmList, setPdmList] = useState<PdmRecord[]>([]);

  // Subscribe Daily Inputs
  useEffect(() => {
    const unsubInputs = subscribeDailyInputs(
      selectedMemberId === 'all' ? null : selectedMemberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setInputs(data);
        } else if (useDemoData) {
          const filtered =
            selectedMemberId === 'all'
              ? DEMO_DAILY_INPUTS
              : DEMO_DAILY_INPUTS.filter((d) => d.memberId === selectedMemberId);
          setInputs(filtered);
        } else {
          setInputs([]);
        }
      }
    );

    // Subscribe PDM Records
    const unsubPdm = subscribePdmRecords(
      selectedMemberId === 'all' ? null : selectedMemberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setPdmList(data);
        } else if (useDemoData) {
          const filtered =
            selectedMemberId === 'all'
              ? DEMO_PDM_RECORDS
              : DEMO_PDM_RECORDS.filter((p) => p.memberId === selectedMemberId);
          setPdmList(filtered);
        } else {
          setPdmList([]);
        }
      }
    );

    return () => {
      unsubInputs();
      unsubPdm();
    };
  }, [isAdmin, selectedMemberId, useDemoData]);

  // 4 Varian Produk Yakult Penjualan
  // 1. YO = MERAH (#D92D32)
  // 2. OM = ORANYE (#F28C28)
  // 3. OS = PINK (#E875A9)
  // 4. YT = BIRU (#2689D8)
  const totalSoldYO = inputs.reduce(
    (sum, i) => sum + (i.soldYO ?? (i.soldRegular ? Math.round(i.soldRegular * 0.75) : 0)),
    0
  );
  const totalSoldOM = inputs.reduce(
    (sum, i) =>
      sum +
      (i.soldOM ??
        (i.soldRegular ? i.soldRegular - Math.round(i.soldRegular * 0.75) : 0)),
    0
  );
  const totalSoldOS = inputs.reduce(
    (sum, i) => sum + (i.soldOS ?? (i.soldLight ? Math.round(i.soldLight * 0.5) : 0)),
    0
  );
  const totalSoldYT = inputs.reduce(
    (sum, i) =>
      sum +
      (i.soldYT ??
        (i.soldLight ? i.soldLight - Math.round(i.soldLight * 0.5) : 0)),
    0
  );

  const totalRegular = inputs.reduce((sum, i) => sum + (i.soldRegular || 0), 0);
  const totalLight = inputs.reduce((sum, i) => sum + (i.soldLight || 0), 0);
  const totalSold = totalSoldYO + totalSoldOM + totalSoldOS + totalSoldYT || (totalRegular + totalLight);
  const totalDropping = inputs.reduce((sum, i) => sum + (i.droppingStock || 0), 0);
  const totalDeposit = inputs.reduce((sum, i) => sum + (i.cashDeposit || 0), 0);
  const totalBroken = inputs.reduce((sum, i) => sum + (i.brokenStock || 0), 0);
  const avgSoldPerRecord = inputs.length > 0 ? Math.round(totalSold / inputs.length) : 0;

  // Total PDM (Pesanan Di Muka) per Varian
  const totalPdmYO = pdmList.reduce((sum, p) => sum + (p.pdmYO || 0), 0);
  const totalPdmOM = pdmList.reduce((sum, p) => sum + (p.pdmOM || 0), 0);
  const totalPdmOS = pdmList.reduce((sum, p) => sum + (p.pdmOS || 0), 0);
  const totalPdmYT = pdmList.reduce((sum, p) => sum + (p.pdmYT || 0), 0);
  const totalPDM = totalPdmYO + totalPdmOM + totalPdmOS + totalPdmYT;

  // Rumus: KEMBALI BOTOL = PDM - BOTOL TERJUAL
  // Aturan D4: Jangan mengubah hasil negatif menjadi nol!
  const totalReturnYO = totalPdmYO - totalSoldYO;
  const totalReturnOM = totalPdmOM - totalSoldOM;
  const totalReturnOS = totalPdmOS - totalSoldOS;
  const totalReturnYT = totalPdmYT - totalSoldYT;
  const totalReturnBotol = totalPDM - totalSold;

  const hasNegativeSummary =
    totalReturnYO < 0 || totalReturnOM < 0 || totalReturnOS < 0 || totalReturnYT < 0 || totalReturnBotol < 0;

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    if (inputs.length === 0) {
      alert('Tidak ada data untuk diekspor.');
      return;
    }
    const headers = [
      'Tanggal',
      'Anggota',
      'Dropping',
      'Jual YO (Merah)',
      'Jual OM (Oranye)',
      'Jual OS (Pink)',
      'Jual YT (Biru)',
      'Total Terjual',
      'Setoran Kas (Rp)',
    ];
    const rows = inputs.map((i) => {
      const yo = i.soldYO ?? 0;
      const om = i.soldOM ?? 0;
      const os = i.soldOS ?? 0;
      const yt = i.soldYT ?? 0;
      const sold = yo + om + os + yt || (i.soldRegular || 0) + (i.soldLight || 0);
      return [
        `"${i.date}"`,
        `"${i.memberName}"`,
        i.droppingStock,
        yo,
        om,
        os,
        yt,
        sold,
        i.cashDeposit,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan_DP_JBR4_${period}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
              Laporan Ringkasan Kinerja
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Rekapitulasi penjualan, PDM, kembali botol, dan setoran kas DP JBR 4
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleExportCSV}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              title="Ekspor CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              title="Cetak Laporan"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="pt-2 border-t border-slate-100 space-y-2">
          {/* Period selector */}
          <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-medium">
            <button
              onClick={() => setPeriod('harian')}
              className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'harian' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Harian
            </button>
            <button
              onClick={() => setPeriod('mingguan')}
              className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'mingguan' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Mingguan
            </button>
            <button
              onClick={() => setPeriod('bulanan')}
              className={`flex-1 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'bulanan' ? 'bg-white text-emerald-900 shadow-xs font-bold' : 'text-slate-600'
              }`}
            >
              Bulanan
            </button>
          </div>

          {/* Member filter */}
          <select
            value={selectedMemberId}
            onChange={(e) => setSelectedMemberId(e.target.value)}
            className="w-full text-xs font-semibold p-2 rounded-xl border border-slate-300 bg-white"
          >
            <option value="all">Semua Anggota (Total DP JBR 4)</option>
            {allMembers
              .filter((m) => m.role === 'yl')
              .map((m) => (
                <option key={m.memberId} value={m.memberId}>
                  {m.code} - {m.name}
                </option>
              ))}
          </select>
        </div>
      </div>

      {/* REKAP PDM, PENJUALAN & KEMBALI BOTOL (4 VARIAN PRODUK) - REQUIREMENT E */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <RotateCcw className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">
                Rekap PDM, Penjualan & Kembali Botol (4 Varian)
              </h3>
              <p className="text-[10.5px] text-slate-500">
                Rumus: Kembali Botol = PDM &minus; Botol Terjual ({period.toUpperCase()})
              </p>
            </div>
          </div>
        </div>

        {hasNegativeSummary && (
          <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-semibold text-[11px]">
              Peringatan Selisih Negatif: Terdapat varian di mana penjualan melebihi PDM. Angka negatif dipertahankan dan tidak diubah menjadi nol.
            </span>
          </div>
        )}

        {/* 4 Variant Comparison Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* YO */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.YO.hex }}
            className={`p-2.5 rounded-xl border space-y-1 ${
              totalReturnYO < 0 ? 'bg-red-50/70 border-red-400' : 'bg-slate-50/70'
            }`}
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YO" size="sm" />
              <span className="text-[10px] font-bold text-slate-600">Original</span>
            </div>
            <div className="text-[10.5px] text-slate-500 font-mono flex items-center justify-between pt-0.5">
              <span>PDM: {totalPdmYO}</span>
              <span>Jual: {totalSoldYO}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
              <span className="text-[10px] font-bold text-slate-600">Kembali:</span>
              <span
                className={`text-sm font-black font-mono ${
                  totalReturnYO < 0 ? 'text-red-600' : 'text-slate-800'
                }`}
              >
                {totalReturnYO > 0 ? `+${totalReturnYO}` : totalReturnYO} btl
              </span>
            </div>
          </div>

          {/* OM */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.OM.hex }}
            className={`p-2.5 rounded-xl border space-y-1 ${
              totalReturnOM < 0 ? 'bg-red-50/70 border-red-400' : 'bg-slate-50/70'
            }`}
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OM" size="sm" />
              <span className="text-[10px] font-bold text-slate-600">Mangga</span>
            </div>
            <div className="text-[10.5px] text-slate-500 font-mono flex items-center justify-between pt-0.5">
              <span>PDM: {totalPdmOM}</span>
              <span>Jual: {totalSoldOM}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
              <span className="text-[10px] font-bold text-slate-600">Kembali:</span>
              <span
                className={`text-sm font-black font-mono ${
                  totalReturnOM < 0 ? 'text-red-600' : 'text-slate-800'
                }`}
              >
                {totalReturnOM > 0 ? `+${totalReturnOM}` : totalReturnOM} btl
              </span>
            </div>
          </div>

          {/* OS */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.OS.hex }}
            className={`p-2.5 rounded-xl border space-y-1 ${
              totalReturnOS < 0 ? 'bg-red-50/70 border-red-400' : 'bg-slate-50/70'
            }`}
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="OS" size="sm" />
              <span className="text-[10px] font-bold text-slate-600">Strawberry</span>
            </div>
            <div className="text-[10.5px] text-slate-500 font-mono flex items-center justify-between pt-0.5">
              <span>PDM: {totalPdmOS}</span>
              <span>Jual: {totalSoldOS}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
              <span className="text-[10px] font-bold text-slate-600">Kembali:</span>
              <span
                className={`text-sm font-black font-mono ${
                  totalReturnOS < 0 ? 'text-red-600' : 'text-slate-800'
                }`}
              >
                {totalReturnOS > 0 ? `+${totalReturnOS}` : totalReturnOS} btl
              </span>
            </div>
          </div>

          {/* YT */}
          <div
            style={{ borderColor: PRODUCT_VARIANTS.YT.hex }}
            className={`p-2.5 rounded-xl border space-y-1 ${
              totalReturnYT < 0 ? 'bg-red-50/70 border-red-400' : 'bg-slate-50/70'
            }`}
          >
            <div className="flex items-center justify-between">
              <ProductBadge code="YT" size="sm" />
              <span className="text-[10px] font-bold text-slate-600">Light</span>
            </div>
            <div className="text-[10.5px] text-slate-500 font-mono flex items-center justify-between pt-0.5">
              <span>PDM: {totalPdmYT}</span>
              <span>Jual: {totalSoldYT}</span>
            </div>
            <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
              <span className="text-[10px] font-bold text-slate-600">Kembali:</span>
              <span
                className={`text-sm font-black font-mono ${
                  totalReturnYT < 0 ? 'text-red-600' : 'text-slate-800'
                }`}
              >
                {totalReturnYT > 0 ? `+${totalReturnYT}` : totalReturnYT} btl
              </span>
            </div>
          </div>
        </div>

        {/* Total PDM vs Penjualan vs Kembali Botol Bar */}
        <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between text-xs">
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              TOTAL KEMBALI BOTOL DP JBR 4
            </p>
            <p className="text-[11px] text-slate-300 font-mono">
              Total PDM ({totalPDM}) &minus; Total Terjual ({totalSold})
            </p>
          </div>
          <div className="text-right">
            <span
              className={`text-xl font-black font-mono ${
                totalReturnBotol < 0 ? 'text-red-400' : 'text-emerald-400'
              }`}
            >
              {totalReturnBotol > 0 ? `+${totalReturnBotol}` : totalReturnBotol}
            </span>
            <span className="text-xs text-slate-300 ml-1">botol</span>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-emerald-900 text-white p-3 rounded-xl shadow-xs">
          <p className="text-[11px] text-emerald-200 font-medium">Total Botol Terjual</p>
          <p className="text-xl font-black mt-0.5">{totalSold.toLocaleString('id-ID')} btl</p>
          <p className="text-[10px] text-emerald-300 mt-0.5">
            4 Varian: YO, OM, OS, YT
          </p>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] text-slate-500 font-medium">Total Dropping</p>
          <p className="text-xl font-black text-slate-800 mt-0.5">
            {totalDropping.toLocaleString('id-ID')} btl
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Botol rusak: {totalBroken}</p>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] text-slate-500 font-medium">Total Setoran Kas</p>
          <p className="text-sm font-black text-slate-800 mt-0.5 truncate">
            {formatRupiah(totalDeposit)}
          </p>
          <p className="text-[10px] text-emerald-700 font-semibold mt-0.5">Kas tercatat</p>
        </div>

        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] text-slate-500 font-medium">Rata-rata Penjualan</p>
          <p className="text-xl font-black text-slate-800 mt-0.5">{avgSoldPerRecord} btl</p>
          <p className="text-[10px] text-slate-500 mt-0.5">per sesi dropping</p>
        </div>
      </div>

      {/* Detailed Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
            Rincian Transaksi Penjualan ({inputs.length} Catatan)
          </h3>
          {useDemoData && inputs.some((i) => i.isDemo) && <DemoBadge isDemo={true} />}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left whitespace-nowrap">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="p-2.5">Tanggal</th>
                <th className="p-2.5">Petugas YL</th>
                <th className="p-2.5 text-right">Drop</th>
                <th className="p-2.5 text-center text-[#D92D32]">YO</th>
                <th className="p-2.5 text-center text-[#F28C28]">OM</th>
                <th className="p-2.5 text-center text-[#E875A9]">OS</th>
                <th className="p-2.5 text-center text-[#2689D8]">YT</th>
                <th className="p-2.5 text-right font-extrabold text-emerald-800">Total</th>
                <th className="p-2.5 text-right">Setoran Kas</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {inputs.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-6 text-center text-slate-400">
                    Tidak ada data ringkasan untuk filter yang dipilih
                  </td>
                </tr>
              ) : (
                inputs.map((row) => {
                  const yo = row.soldYO ?? (row.soldRegular ? Math.round(row.soldRegular * 0.75) : 0);
                  const om = row.soldOM ?? (row.soldRegular ? row.soldRegular - yo : 0);
                  const os = row.soldOS ?? (row.soldLight ? Math.round(row.soldLight * 0.5) : 0);
                  const yt = row.soldYT ?? (row.soldLight ? row.soldLight - os : 0);
                  const rowSold = yo + om + os + yt || (row.soldRegular || 0) + (row.soldLight || 0);

                  return (
                    <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-2.5 font-mono text-slate-600">
                        {new Date(row.date).toLocaleDateString('id-ID', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </td>
                      <td className="p-2.5 font-semibold text-slate-800">
                        <div className="flex items-center gap-1.5">
                          <span>{row.memberName}</span>
                          {row.isDemo && <DemoBadge isDemo={true} />}
                        </div>
                      </td>
                      <td className="p-2.5 text-right text-slate-600">{row.droppingStock}</td>
                      <td className="p-2.5 text-center font-bold text-[#D92D32] bg-red-50/30">{yo}</td>
                      <td className="p-2.5 text-center font-bold text-[#F28C28] bg-orange-50/30">{om}</td>
                      <td className="p-2.5 text-center font-bold text-[#E875A9] bg-pink-50/30">{os}</td>
                      <td className="p-2.5 text-center font-bold text-[#2689D8] bg-sky-50/30">{yt}</td>
                      <td className="p-2.5 text-right font-black text-emerald-800">
                        {rowSold} btl
                      </td>
                      <td className="p-2.5 text-right font-bold text-slate-800">
                        {formatRupiah(row.cashDeposit)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
