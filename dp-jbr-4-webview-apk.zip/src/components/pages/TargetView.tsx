import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { TargetYL, DailyInput } from '../../types';
import { subscribeTargets, saveTarget, subscribeDailyInputs } from '../../firebase/service';
import { DEMO_TARGETS, DEMO_DAILY_INPUTS } from '../../data/initialMembers';
import { DemoBadge } from '../common/DemoBadge';
import { ProductBadge } from '../common/ProductBadge';
import { PRODUCT_LIST, PRODUCT_VARIANTS } from '../../data/productVariants';
import {
  Target as TargetIcon,
  CheckCircle2,
  Edit3,
  Save,
  X,
  Users,
  Megaphone,
  Award,
  Table as TableIcon,
  LayoutGrid,
} from 'lucide-react';

export const TargetView: React.FC = () => {
  const { activeMember, isAdmin, useDemoData } = useAuth();
  const [targets, setTargets] = useState<TargetYL[]>([]);
  const [dailyInputs, setDailyInputs] = useState<DailyInput[]>([]);
  const [editingTarget, setEditingTarget] = useState<TargetYL | null>(null);
  const [saving, setSaving] = useState(false);
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  useEffect(() => {
    const unsubTargets = subscribeTargets((data) => {
      if (data.length > 0) {
        setTargets(data);
      } else if (useDemoData) {
        setTargets(DEMO_TARGETS);
      }
    });

    const unsubInputs = subscribeDailyInputs(
      isAdmin ? null : activeMember.memberId,
      isAdmin,
      (data) => {
        if (data.length > 0) {
          setDailyInputs(data);
        } else if (useDemoData) {
          setDailyInputs(DEMO_DAILY_INPUTS);
        }
      }
    );

    return () => {
      unsubTargets();
      unsubInputs();
    };
  }, [activeMember.memberId, isAdmin, useDemoData]);

  const handleSaveTarget = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTarget) return;

    setSaving(true);
    try {
      await saveTarget({
        ...editingTarget,
        isDemo: false,
      });
      setEditingTarget(null);
      alert('Target berhasil diperbarui di Cloud Firestore!');
    } catch (err: any) {
      alert('Gagal menyimpan target: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  // Helper to calculate actual sold by variant for a member
  const getMemberActual = (memberId: string) => {
    const memberInputs = dailyInputs.filter((d) => d.memberId === memberId);
    let yo = 0;
    let om = 0;
    let os = 0;
    let yt = 0;
    let total = 0;

    memberInputs.forEach((i) => {
      const itemYO = i.soldYO ?? (i.soldRegular ? Math.round(i.soldRegular * 0.75) : 0);
      const itemOM = i.soldOM ?? (i.soldRegular ? Math.round(i.soldRegular * 0.25) : 0);
      const itemOS = i.soldOS ?? (i.soldLight ? Math.round(i.soldLight * 0.5) : 0);
      const itemYT = i.soldYT ?? (i.soldLight ? Math.round(i.soldLight * 0.5) : 0);
      yo += itemYO;
      om += itemOM;
      os += itemOS;
      yt += itemYT;
      total += itemYO + itemOM + itemOS + itemYT;
    });

    return { yo, om, os, yt, total };
  };

  // Update variant target in edit modal and auto-calculate daily & monthly total
  const handleVariantTargetChange = (
    field: 'targetYO' | 'targetOM' | 'targetOS' | 'targetYT',
    val: number
  ) => {
    if (!editingTarget) return;
    const updated = {
      ...editingTarget,
      [field]: Math.max(0, val),
    };
    const yo = field === 'targetYO' ? Math.max(0, val) : editingTarget.targetYO || 0;
    const om = field === 'targetOM' ? Math.max(0, val) : editingTarget.targetOM || 0;
    const os = field === 'targetOS' ? Math.max(0, val) : editingTarget.targetOS || 0;
    const yt = field === 'targetYT' ? Math.max(0, val) : editingTarget.targetYT || 0;
    const sum = yo + om + os + yt;
    if (sum > 0) {
      updated.dailyBottleTarget = sum;
      updated.monthlyBottleTarget = sum * 25; // 25 hari kerja dropping per bulan
    }
    setEditingTarget(updated);
  };

  // Filter targets based on user role
  const displayTargets = isAdmin
    ? targets
    : targets.filter((t) => t.memberId === activeMember.memberId);

  // Totals for the table view
  const tableTotals = displayTargets.reduce(
    (acc, t) => {
      const act = getMemberActual(t.memberId);
      acc.targetYO += t.targetYO || 0;
      acc.targetOM += t.targetOM || 0;
      acc.targetOS += t.targetOS || 0;
      acc.targetYT += t.targetYT || 0;
      acc.targetTotal += t.dailyBottleTarget || 0;
      acc.realYO += act.yo;
      acc.realOM += act.om;
      acc.realOS += act.os;
      acc.realYT += act.yt;
      acc.realTotal += act.total;
      return acc;
    },
    {
      targetYO: 0,
      targetOM: 0,
      targetOS: 0,
      targetYT: 0,
      targetTotal: 0,
      realYO: 0,
      realOM: 0,
      realOS: 0,
      realYT: 0,
      realTotal: 0,
    }
  );

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-extrabold text-slate-800 flex items-center gap-2">
              <TargetIcon className="w-5 h-5 text-emerald-700" />
              Target & Realisasi Yakult Lady
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Monitoring target harian 4 varian produk, bulanan, pelanggan baru dan propaganda
            </p>
          </div>

          {useDemoData && targets.some((t) => t.isDemo) && <DemoBadge isDemo={true} />}
        </div>

        {/* 4-Variant Identity Legend */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-1.5 sm:gap-2">
          <span className="text-[11px] font-bold text-slate-400 mr-1">Varian:</span>
          {PRODUCT_LIST.map((p) => (
            <div
              key={p.code}
              style={{ borderColor: p.hex }}
              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg border bg-white shadow-2xs"
            >
              <ProductBadge code={p.code} size="sm" />
              <span className="text-[11px] font-semibold text-slate-700">{p.fullName}</span>
            </div>
          ))}
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center justify-between pt-1">
          <span className="text-xs font-semibold text-slate-600">
            Tampilan: {displayTargets.length} Yakult Lady
          </span>
          <div className="inline-flex p-0.5 bg-slate-100 rounded-lg text-xs">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1 rounded-md font-bold flex items-center gap-1 transition-all ${
                viewMode === 'cards'
                  ? 'bg-white text-emerald-800 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Kartu YL</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-md font-bold flex items-center gap-1 transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-emerald-800 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Tabel Realisasi</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: CARDS */}
      {viewMode === 'cards' && (
        <div className="space-y-3">
          {displayTargets.map((target) => {
            const actual = getMemberActual(target.memberId);
            const totalTarget = target.dailyBottleTarget || 200;
            const percent = Math.min(100, Math.round((actual.total / totalTarget) * 100));

            // Variant target values (fallback to proportional if not set)
            const tYO = target.targetYO ?? Math.round(totalTarget * 0.6);
            const tOM = target.targetOM ?? Math.round(totalTarget * 0.2);
            const tOS = target.targetOS ?? Math.round(totalTarget * 0.1);
            const tYT = target.targetYT ?? Math.round(totalTarget * 0.1);

            const variantsData = [
              { ...PRODUCT_VARIANTS.YO, target: tYO, real: actual.yo },
              { ...PRODUCT_VARIANTS.OM, target: tOM, real: actual.om },
              { ...PRODUCT_VARIANTS.OS, target: tOS, real: actual.os },
              { ...PRODUCT_VARIANTS.YT, target: tYT, real: actual.yt },
            ];

            return (
              <div
                key={target.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-800">{target.memberName}</h3>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Periode: {target.periodMonth} &bull; Dropping JBR 4
                      </p>
                    </div>
                  </div>

                  {isAdmin && (
                    <button
                      onClick={() =>
                        setEditingTarget({
                          ...target,
                          targetYO: tYO,
                          targetOM: tOM,
                          targetOS: tOS,
                          targetYT: tYT,
                        })
                      }
                      className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Ubah</span>
                    </button>
                  )}
                </div>

                {/* Overall Daily Progress Bar */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-600">Total Capaian Harian:</span>
                    <span className="text-emerald-800 font-bold">
                      {actual.total} / {totalTarget} botol ({percent}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-linear-to-r from-emerald-600 to-teal-500 rounded-full transition-all duration-300"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                {/* 4 Product Variants Target vs Realization Breakdown */}
                <div className="space-y-1.5">
                  <p className="text-[11px] font-bold text-slate-600">
                    Realisasi vs Target per Varian:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {variantsData.map((v) => {
                      const vPct =
                        v.target > 0 ? Math.min(100, Math.round((v.real / v.target) * 100)) : 0;
                      return (
                        <div
                          key={v.code}
                          style={{ borderColor: v.hex }}
                          className="p-2.5 rounded-xl border bg-slate-50/70 space-y-1.5 shadow-2xs"
                        >
                          <div className="flex items-center justify-between">
                            <ProductBadge code={v.code} size="sm" showName={true} />
                            <span className="text-[10px] font-bold text-slate-500">
                              {vPct}%
                            </span>
                          </div>

                          <div className="flex items-baseline justify-between">
                            <span className="text-xs font-extrabold text-slate-800">
                              {v.real}{' '}
                              <span className="text-[10px] font-normal text-slate-500">
                                / {v.target} btl
                              </span>
                            </span>
                            {v.real >= v.target && (
                              <span title="Target tercapai">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              </span>
                            )}
                          </div>

                          {/* Colored Progress Bar matching exact variant color */}
                          <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                            <div
                              style={{ width: `${vPct}%`, backgroundColor: v.hex }}
                              className="h-full rounded-full transition-all duration-300"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Targets Summary Grid */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1 border-t border-slate-100">
                  <div className="bg-slate-50 p-2 rounded-xl">
                    <p className="text-[10px] text-slate-500">Target Bulanan</p>
                    <p className="font-extrabold text-slate-800 text-sm mt-0.5">
                      {target.monthlyBottleTarget.toLocaleString('id-ID')}
                    </p>
                    <p className="text-[9px] text-slate-400">botol/bulan</p>
                  </div>

                  <div className="bg-slate-50 p-2 rounded-xl">
                    <p className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                      <Users className="w-3 h-3 text-amber-600" /> Pelanggan Baru
                    </p>
                    <p className="font-extrabold text-slate-800 text-sm mt-0.5">
                      {target.newCustomerTarget}
                    </p>
                    <p className="text-[9px] text-slate-400">prospek aktif</p>
                  </div>

                  <div className="bg-slate-50 p-2 rounded-xl">
                    <p className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                      <Megaphone className="w-3 h-3 text-blue-600" /> Propaganda
                    </p>
                    <p className="font-extrabold text-slate-800 text-sm mt-0.5">
                      {target.propagandaTarget}
                    </p>
                    <p className="text-[9px] text-slate-400">kali/bulan</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW MODE 2: TABEL TARGET & REALISASI */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-3 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-xs text-slate-800 uppercase tracking-wide">
              Matriks Target vs Realisasi per Varian (DP JBR 4)
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Format: Realisasi (botol) / Target (botol)
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100/80 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-2.5 whitespace-nowrap">Yakult Lady</th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="YO" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.YO.hex }}>YO</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="OM" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.OM.hex }}>OM</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="OS" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.OS.hex }}>OS</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      <ProductBadge code="YT" size="sm" />
                      <span style={{ color: PRODUCT_VARIANTS.YT.hex }}>YT</span>
                    </div>
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap font-extrabold text-slate-800">
                    Total
                  </th>
                  <th className="p-2.5 text-center whitespace-nowrap">% Capai</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {displayTargets.map((target) => {
                  const act = getMemberActual(target.memberId);
                  const totalTarget = target.dailyBottleTarget || 200;
                  const tYO = target.targetYO ?? Math.round(totalTarget * 0.6);
                  const tOM = target.targetOM ?? Math.round(totalTarget * 0.2);
                  const tOS = target.targetOS ?? Math.round(totalTarget * 0.1);
                  const tYT = target.targetYT ?? Math.round(totalTarget * 0.1);
                  const pct = Math.min(100, Math.round((act.total / totalTarget) * 100));

                  return (
                    <tr key={target.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="p-2.5 font-bold text-slate-800 whitespace-nowrap">
                        {target.memberName}
                      </td>

                      {/* YO */}
                      <td className="p-2.5 text-center whitespace-nowrap">
                        <span className="font-extrabold" style={{ color: PRODUCT_VARIANTS.YO.hex }}>
                          {act.yo}
                        </span>
                        <span className="text-[10px] text-slate-400">/{tYO}</span>
                      </td>

                      {/* OM */}
                      <td className="p-2.5 text-center whitespace-nowrap">
                        <span className="font-extrabold" style={{ color: PRODUCT_VARIANTS.OM.hex }}>
                          {act.om}
                        </span>
                        <span className="text-[10px] text-slate-400">/{tOM}</span>
                      </td>

                      {/* OS */}
                      <td className="p-2.5 text-center whitespace-nowrap">
                        <span className="font-extrabold" style={{ color: PRODUCT_VARIANTS.OS.hex }}>
                          {act.os}
                        </span>
                        <span className="text-[10px] text-slate-400">/{tOS}</span>
                      </td>

                      {/* YT */}
                      <td className="p-2.5 text-center whitespace-nowrap">
                        <span className="font-extrabold" style={{ color: PRODUCT_VARIANTS.YT.hex }}>
                          {act.yt}
                        </span>
                        <span className="text-[10px] text-slate-400">/{tYT}</span>
                      </td>

                      {/* Total */}
                      <td className="p-2.5 text-center whitespace-nowrap font-black text-slate-800">
                        {act.total}
                        <span className="text-[10px] font-normal text-slate-400">/{totalTarget}</span>
                      </td>

                      {/* % Capai */}
                      <td className="p-2.5 text-center whitespace-nowrap">
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            pct >= 100
                              ? 'bg-emerald-100 text-emerald-800'
                              : pct >= 80
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {pct}%
                        </span>
                      </td>
                    </tr>
                  );
                })}

                {/* Table Totals Row */}
                <tr className="bg-slate-100 font-extrabold text-slate-800 border-t-2 border-slate-300">
                  <td className="p-2.5">TOTAL DP JBR 4</td>
                  <td className="p-2.5 text-center" style={{ color: PRODUCT_VARIANTS.YO.hex }}>
                    {tableTotals.realYO}
                    <span className="text-[10px] text-slate-500">/{tableTotals.targetYO}</span>
                  </td>
                  <td className="p-2.5 text-center" style={{ color: PRODUCT_VARIANTS.OM.hex }}>
                    {tableTotals.realOM}
                    <span className="text-[10px] text-slate-500">/{tableTotals.targetOM}</span>
                  </td>
                  <td className="p-2.5 text-center" style={{ color: PRODUCT_VARIANTS.OS.hex }}>
                    {tableTotals.realOS}
                    <span className="text-[10px] text-slate-500">/{tableTotals.targetOS}</span>
                  </td>
                  <td className="p-2.5 text-center" style={{ color: PRODUCT_VARIANTS.YT.hex }}>
                    {tableTotals.realYT}
                    <span className="text-[10px] text-slate-500">/{tableTotals.targetYT}</span>
                  </td>
                  <td className="p-2.5 text-center font-black">
                    {tableTotals.realTotal}
                    <span className="text-[10px] font-normal text-slate-500">
                      /{tableTotals.targetTotal}
                    </span>
                  </td>
                  <td className="p-2.5 text-center">
                    <span className="inline-block px-2 py-0.5 rounded bg-emerald-800 text-white text-[10px] font-extrabold">
                      {tableTotals.targetTotal > 0
                        ? Math.min(
                            100,
                            Math.round((tableTotals.realTotal / tableTotals.targetTotal) * 100)
                          )
                        : 0}
                      %
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit Target Modal (Admin Only) with 4-variant inputs */}
      {editingTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-xl p-4 space-y-3.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="font-bold text-sm text-slate-800">
                  Ubah Target: {editingTarget.memberName}
                </h3>
                <p className="text-[11px] text-slate-500">
                  Target harian 4 varian produk & target bulanan
                </p>
              </div>
              <button
                onClick={() => setEditingTarget(null)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center cursor-pointer hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTarget} className="space-y-3 text-xs">
              {/* 4 Variant Target Inputs */}
              <div className="space-y-2">
                <label className="block font-bold text-slate-700">
                  Target Harian per Varian Produk:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {/* Target YO */}
                  <div
                    style={{ borderColor: PRODUCT_VARIANTS.YO.hex }}
                    className="p-2 rounded-xl border bg-red-50/40"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <ProductBadge code="YO" size="sm" />
                      <span className="text-[10px] font-bold" style={{ color: PRODUCT_VARIANTS.YO.hex }}>
                        Original
                      </span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      value={editingTarget.targetYO ?? 0}
                      onChange={(e) =>
                        handleVariantTargetChange('targetYO', parseInt(e.target.value) || 0)
                      }
                      className="w-full p-1.5 border border-slate-300 rounded-lg text-sm font-extrabold text-slate-800 bg-white"
                      placeholder="0"
                    />
                  </div>

                  {/* Target OM */}
                  <div
                    style={{ borderColor: PRODUCT_VARIANTS.OM.hex }}
                    className="p-2 rounded-xl border bg-orange-50/40"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <ProductBadge code="OM" size="sm" />
                      <span className="text-[10px] font-bold" style={{ color: PRODUCT_VARIANTS.OM.hex }}>
                        Mangga
                      </span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      value={editingTarget.targetOM ?? 0}
                      onChange={(e) =>
                        handleVariantTargetChange('targetOM', parseInt(e.target.value) || 0)
                      }
                      className="w-full p-1.5 border border-slate-300 rounded-lg text-sm font-extrabold text-slate-800 bg-white"
                      placeholder="0"
                    />
                  </div>

                  {/* Target OS */}
                  <div
                    style={{ borderColor: PRODUCT_VARIANTS.OS.hex }}
                    className="p-2 rounded-xl border bg-pink-50/40"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <ProductBadge code="OS" size="sm" />
                      <span className="text-[10px] font-bold" style={{ color: PRODUCT_VARIANTS.OS.hex }}>
                        Strawberry
                      </span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      value={editingTarget.targetOS ?? 0}
                      onChange={(e) =>
                        handleVariantTargetChange('targetOS', parseInt(e.target.value) || 0)
                      }
                      className="w-full p-1.5 border border-slate-300 rounded-lg text-sm font-extrabold text-slate-800 bg-white"
                      placeholder="0"
                    />
                  </div>

                  {/* Target YT */}
                  <div
                    style={{ borderColor: PRODUCT_VARIANTS.YT.hex }}
                    className="p-2 rounded-xl border bg-sky-50/40"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <ProductBadge code="YT" size="sm" />
                      <span className="text-[10px] font-bold" style={{ color: PRODUCT_VARIANTS.YT.hex }}>
                        Light
                      </span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      value={editingTarget.targetYT ?? 0}
                      onChange={(e) =>
                        handleVariantTargetChange('targetYT', parseInt(e.target.value) || 0)
                      }
                      className="w-full p-1.5 border border-slate-300 rounded-lg text-sm font-extrabold text-slate-800 bg-white"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>

              {/* Total Daily Bottle Target */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700">Total Target Botol Harian</label>
                  <span className="text-[10px] text-slate-400">Otomatis dari 4 varian</span>
                </div>
                <input
                  type="number"
                  min="0"
                  value={editingTarget.dailyBottleTarget}
                  onChange={(e) =>
                    setEditingTarget({
                      ...editingTarget,
                      dailyBottleTarget: Math.max(0, parseInt(e.target.value) || 0),
                    })
                  }
                  required
                  className="w-full p-2 border border-slate-300 rounded-lg text-sm font-bold bg-slate-50"
                />
              </div>

              {/* Monthly Bottle Target */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Target Botol Bulanan (25 hari)
                </label>
                <input
                  type="number"
                  min="0"
                  value={editingTarget.monthlyBottleTarget}
                  onChange={(e) =>
                    setEditingTarget({
                      ...editingTarget,
                      monthlyBottleTarget: Math.max(0, parseInt(e.target.value) || 0),
                    })
                  }
                  required
                  className="w-full p-2 border border-slate-300 rounded-lg text-sm font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Target Pelanggan Baru
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editingTarget.newCustomerTarget}
                    onChange={(e) =>
                      setEditingTarget({
                        ...editingTarget,
                        newCustomerTarget: Math.max(0, parseInt(e.target.value) || 0),
                      })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Target Propaganda
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editingTarget.propagandaTarget}
                    onChange={(e) =>
                      setEditingTarget({
                        ...editingTarget,
                        propagandaTarget: Math.max(0, parseInt(e.target.value) || 0),
                      })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Menyimpan...' : 'Simpan Perubahan Target'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
