import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDocs,
  setDoc,
  onSnapshot,
} from 'firebase/firestore';
import { auth, db, testFirestoreConnection } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/errors';
import { Member, UserRole } from '../types';
import { INITIAL_MEMBERS } from '../data/initialMembers';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  activeMember: Member;
  allMembers: Member[];
  isOnline: boolean;
  useDemoData: boolean;
  setUseDemoData: (val: boolean) => void;
  switchActiveMember: (memberId: string) => void;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  seedInitialMembersToFirestore: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Admin identifier matching current workspace user email
const PRIMARY_ADMIN_EMAIL = 'andikaprasetya173@gmail.com';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [allMembers, setAllMembers] = useState<Member[]>(INITIAL_MEMBERS);
  const [activeMember, setActiveMember] = useState<Member>(INITIAL_MEMBERS[0]);
  const [useDemoData, setUseDemoData] = useState<boolean>(true);

  // Check if current user is admin
  const isAdmin = Boolean(
    (user?.email && user.email.toLowerCase() === PRIMARY_ADMIN_EMAIL) ||
    activeMember.role === 'admin'
  );

  // 1. Initial connectivity test
  useEffect(() => {
    testFirestoreConnection().then((connected) => {
      setIsOnline(connected);
    });
  }, []);

  // 2. Auth state observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(false);

      if (currentUser?.email && currentUser.email.toLowerCase() === PRIMARY_ADMIN_EMAIL) {
        // Automatically set active member to Admin
        const adminProfile = allMembers.find((m) => m.role === 'admin') || INITIAL_MEMBERS[0];
        setActiveMember(adminProfile);
      }
    });

    return () => unsubscribe();
  }, [allMembers]);

  // 3. Listen to members collection from Firestore
  useEffect(() => {
    const colRef = collection(db, 'members');
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        if (!snapshot.empty) {
          const loadedMembers: Member[] = [];
          snapshot.forEach((docSnap) => {
            loadedMembers.push(docSnap.data() as Member);
          });
          // Sort members: admin first, then YL-01 to YL-07
          loadedMembers.sort((a, b) => {
            if (a.role === 'admin') return -1;
            if (b.role === 'admin') return 1;
            return a.code.localeCompare(b.code);
          });
          setAllMembers(loadedMembers);
        } else {
          // If Firestore is empty, we fall back to initial 7 members
          setAllMembers(INITIAL_MEMBERS);
        }
      },
      (error) => {
        console.warn('Real-time members listener note:', error.message);
        // Do not crash the entire app if offline, keep initial members
        setAllMembers(INITIAL_MEMBERS);
      }
    );

    return () => unsub();
  }, []);

  // Function to seed 7 Yakult Lady + 1 Admin to Firestore
  const seedInitialMembersToFirestore = async () => {
    try {
      for (const m of INITIAL_MEMBERS) {
        await setDoc(doc(db, 'members', m.memberId), {
          ...m,
          updatedAt: new Date().toISOString(),
        });
      }
      alert('Data 7 Yakult Lady & Admin berhasil disinkronisasi ke Cloud Firestore!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'members');
    }
  };

  const switchActiveMember = (memberId: string) => {
    const found = allMembers.find((m) => m.memberId === memberId);
    if (found) {
      setActiveMember(found);
    }
  };

  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const res = await signInWithPopup(auth, provider);
      if (res.user.email?.toLowerCase() === PRIMARY_ADMIN_EMAIL) {
        const adminProfile = allMembers.find((m) => m.role === 'admin') || INITIAL_MEMBERS[0];
        setActiveMember(adminProfile);
      }
    } catch (error) {
      console.error('Google Sign-In failed:', error);
      throw error;
    }
  };

  const signOut = async () => {
    await fbSignOut(auth);
    setUser(null);
    setActiveMember(INITIAL_MEMBERS[1]); // Default to first YL on logout
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAdmin,
        activeMember,
        allMembers,
        isOnline,
        useDemoData,
        setUseDemoData,
        switchActiveMember,
        signInWithGoogle,
        signOut,
        seedInitialMembersToFirestore,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
