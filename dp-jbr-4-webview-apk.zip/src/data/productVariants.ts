import { ProductCode } from '../types';

export interface ProductVariantConfig {
  code: ProductCode;
  name: string;
  fullName: string;
  hex: string;
  badgeBg: string;
  badgeText: string;
  cardBorder: string;
  cardBg: string;
  cardText: string;
  dotBg: string;
  description: string;
}

export const PRODUCT_VARIANTS: Record<ProductCode, ProductVariantConfig> = {
  YO: {
    code: 'YO',
    name: 'Original',
    fullName: 'Yakult Original',
    hex: '#D92D32', // MERAH
    badgeBg: 'bg-[#D92D32]',
    badgeText: 'text-white',
    cardBorder: 'border-[#D92D32]',
    cardBg: 'bg-red-50/70',
    cardText: 'text-[#D92D32]',
    dotBg: 'bg-[#D92D32]',
    description: 'Varian Original (Merah)',
  },
  OM: {
    code: 'OM',
    name: 'Mangga',
    fullName: 'Yakult Mangga',
    hex: '#F28C28', // ORANYE
    badgeBg: 'bg-[#F28C28]',
    badgeText: 'text-white',
    cardBorder: 'border-[#F28C28]',
    cardBg: 'bg-orange-50/70',
    cardText: 'text-[#F28C28]',
    dotBg: 'bg-[#F28C28]',
    description: 'Varian Mangga (Oranye)',
  },
  OS: {
    code: 'OS',
    name: 'Strawberry',
    fullName: 'Yakult Strawberry',
    hex: '#E875A9', // PINK
    badgeBg: 'bg-[#E875A9]',
    badgeText: 'text-white',
    cardBorder: 'border-[#E875A9]',
    cardBg: 'bg-pink-50/70',
    cardText: 'text-[#E875A9]',
    dotBg: 'bg-[#E875A9]',
    description: 'Varian Strawberry (Pink)',
  },
  YT: {
    code: 'YT',
    name: 'Light',
    fullName: 'Yakult Light',
    hex: '#2689D8', // BIRU
    badgeBg: 'bg-[#2689D8]',
    badgeText: 'text-white',
    cardBorder: 'border-[#2689D8]',
    cardBg: 'bg-sky-50/70',
    cardText: 'text-[#2689D8]',
    dotBg: 'bg-[#2689D8]',
    description: 'Varian Light (Biru)',
  },
};

export const PRODUCT_LIST: ProductVariantConfig[] = [
  PRODUCT_VARIANTS.YO,
  PRODUCT_VARIANTS.OM,
  PRODUCT_VARIANTS.OS,
  PRODUCT_VARIANTS.YT,
];
