import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore using database ID specified in config
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Connectivity state tracker
export let isFirestoreOnline = false;

// Connection test on boot as mandated by Firebase Skill
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    // Attempt pinging server connection
    await getDocFromServer(doc(db, 'system_health', 'ping'));
    isFirestoreOnline = true;
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or network restricted.');
      isFirestoreOnline = false;
    } else {
      // Document may not exist, but connection to server succeeded
      isFirestoreOnline = true;
    }
    return isFirestoreOnline;
  }
}
