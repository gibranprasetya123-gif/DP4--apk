import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db, auth } from './config';
import { handleFirestoreError, OperationType } from './errors';
import {
  DailyInput,
  PdmRecord,
  TargetYL,
  PlasticsAndBottles,
  Customer,
  Propaganda,
  Member,
} from '../types';

// ==================== DAILY INPUTS ====================

export async function saveDailyInput(
  input: Omit<DailyInput, 'id' | 'createdAt' | 'ownerUid'> & { id?: string }
): Promise<string> {
  const path = 'daily_inputs';
  const id = input.id || `input_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const ownerUid = auth.currentUser?.uid || 'anonymous_user';

  const payload: DailyInput = {
    ...input,
    id,
    ownerUid,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, path, id), payload);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deleteDailyInput(id: string): Promise<void> {
  const path = `daily_inputs/${id}`;
  try {
    await deleteDoc(doc(db, 'daily_inputs', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeDailyInputs(
  memberId: string | null,
  isAdmin: boolean,
  callback: (data: DailyInput[]) => void
) {
  const path = 'daily_inputs';
  const colRef = collection(db, path);
  
  // If not admin and memberId is provided, query by memberId
  const q = !isAdmin && memberId
    ? query(colRef, where('memberId', '==', memberId))
    : colRef;

  return onSnapshot(
    q,
    (snapshot) => {
      const items: DailyInput[] = [];
      snapshot.forEach((d) => items.push(d.data() as DailyInput));
      // Sort by date descending
      items.sort((a, b) => b.date.localeCompare(a.date));
      callback(items);
    },
    (error) => {
      console.warn('subscribeDailyInputs note:', error.message);
      callback([]);
    }
  );
}

// ==================== PDM (PESANAN DI MUKA) ====================

export async function savePdmRecord(
  record: Omit<PdmRecord, 'id' | 'createdAt' | 'ownerUid'> & { id?: string }
): Promise<string> {
  const path = 'pdm_records';
  const id = record.id || `pdm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const ownerUid = auth.currentUser?.uid || 'anonymous_user';

  const total = (record.pdmYO || 0) + (record.pdmOM || 0) + (record.pdmOS || 0) + (record.pdmYT || 0);

  const payload: PdmRecord = {
    ...record,
    id,
    totalPDM: total,
    ownerUid,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, path, id), payload);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/${id}`);
  }
}

export async function deletePdmRecord(id: string): Promise<void> {
  const path = `pdm_records/${id}`;
  try {
    await deleteDoc(doc(db, 'pdm_records', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribePdmRecords(
  memberId: string | null,
  isAdmin: boolean,
  callback: (data: PdmRecord[]) => void
) {
  const path = 'pdm_records';
  const colRef = collection(db, path);

  const q = !isAdmin && memberId
    ? query(colRef, where('memberId', '==', memberId))
    : colRef;

  return onSnapshot(
    q,
    (snapshot) => {
      const items: PdmRecord[] = [];
      snapshot.forEach((d) => items.push(d.data() as PdmRecord));
      items.sort((a, b) => b.date.localeCompare(a.date));
      callback(items);
    },
    (error) => {
      console.warn('subscribePdmRecords note:', error.message);
      callback([]);
    }
  );
}

// ==================== TARGETS ====================

export async function saveTarget(target: TargetYL): Promise<void> {
  const path = `targets/${target.id}`;
  try {
    await setDoc(doc(db, 'targets', target.id), {
      ...target,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeTargets(callback: (data: TargetYL[]) => void) {
  const colRef = collection(db, 'targets');
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: TargetYL[] = [];
      snapshot.forEach((d) => items.push(d.data() as TargetYL));
      callback(items);
    },
    (error) => {
      console.warn('subscribeTargets note:', error.message);
      callback([]);
    }
  );
}

// ==================== PLASTICS & BOTTLES ====================

export async function savePlasticsAndBottles(
  record: Omit<PlasticsAndBottles, 'id' | 'ownerUid'> & { id?: string }
): Promise<string> {
  const id = record.id || `pb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const ownerUid = auth.currentUser?.uid || 'anonymous_user';
  const payload: PlasticsAndBottles = {
    ...record,
    id,
    ownerUid,
  };

  try {
    await setDoc(doc(db, 'plastics_bottles', id), payload);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `plastics_bottles/${id}`);
  }
}

export function subscribePlasticsAndBottles(
  memberId: string | null,
  isAdmin: boolean,
  callback: (data: PlasticsAndBottles[]) => void
) {
  const colRef = collection(db, 'plastics_bottles');
  const q = !isAdmin && memberId
    ? query(colRef, where('memberId', '==', memberId))
    : colRef;

  return onSnapshot(
    q,
    (snapshot) => {
      const items: PlasticsAndBottles[] = [];
      snapshot.forEach((d) => items.push(d.data() as PlasticsAndBottles));
      items.sort((a, b) => b.date.localeCompare(a.date));
      callback(items);
    },
    (error) => {
      console.warn('subscribePlasticsAndBottles note:', error.message);
      callback([]);
    }
  );
}

// ==================== CUSTOMERS ====================

export async function saveCustomer(
  customer: Omit<Customer, 'id' | 'ownerUid'> & { id?: string }
): Promise<string> {
  const id = customer.id || `cust_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const ownerUid = auth.currentUser?.uid || 'anonymous_user';
  const payload: Customer = {
    ...customer,
    id,
    ownerUid,
  };

  try {
    await setDoc(doc(db, 'customers', id), payload);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `customers/${id}`);
  }
}

export async function deleteCustomer(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'customers', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `customers/${id}`);
  }
}

export function subscribeCustomers(
  memberId: string | null,
  isAdmin: boolean,
  callback: (data: Customer[]) => void
) {
  const colRef = collection(db, 'customers');
  const q = !isAdmin && memberId
    ? query(colRef, where('memberId', '==', memberId))
    : colRef;

  return onSnapshot(
    q,
    (snapshot) => {
      const items: Customer[] = [];
      snapshot.forEach((d) => items.push(d.data() as Customer));
      callback(items);
    },
    (error) => {
      console.warn('subscribeCustomers note:', error.message);
      callback([]);
    }
  );
}

// ==================== PROPAGANDA ====================

export async function savePropaganda(
  prop: Omit<Propaganda, 'id' | 'ownerUid'> & { id?: string }
): Promise<string> {
  const id = prop.id || `prop_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const ownerUid = auth.currentUser?.uid || 'anonymous_user';
  const payload: Propaganda = {
    ...prop,
    id,
    ownerUid,
  };

  try {
    await setDoc(doc(db, 'propaganda', id), payload);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `propaganda/${id}`);
  }
}

export async function deletePropaganda(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'propaganda', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `propaganda/${id}`);
  }
}

export function subscribePropaganda(
  memberId: string | null,
  isAdmin: boolean,
  callback: (data: Propaganda[]) => void
) {
  const colRef = collection(db, 'propaganda');
  const q = !isAdmin && memberId
    ? query(colRef, where('memberId', '==', memberId))
    : colRef;

  return onSnapshot(
    q,
    (snapshot) => {
      const items: Propaganda[] = [];
      snapshot.forEach((d) => items.push(d.data() as Propaganda));
      items.sort((a, b) => b.date.localeCompare(a.date));
      callback(items);
    },
    (error) => {
      console.warn('subscribePropaganda note:', error.message);
      callback([]);
    }
  );
}
