/**
 * Types & Interfaces for DP JBR 4 (Dropping Jember 4)
 * Administrasi dan Monitoring Kinerja Yakult Lady
 */

export type UserRole = 'admin' | 'yl';

export interface Member {
  memberId: string; // e.g. yl_titin_r
  name: string;
  code: string; // YL-01 s/d YL-07 atau ADM-01
  role: UserRole;
  routeArea: string; // Kaliwates, Sumbersari, Patrang, Kebonsari, Mangli, Wirolegi, Kranjingan
  phone: string;
  status: 'active' | 'inactive';
  authUid?: string;
  updatedAt?: string;
}

export type ProductCode = 'YO' | 'OM' | 'OS' | 'YT';

export interface DailyInput {
  id: string;
  memberId: string;
  memberName: string;
  date: string; // YYYY-MM-DD
  droppingStock: number; // botol awal dari DP
  soldRegular: number; // botol Yakult Original / Regular (backward compatible)
  soldLight: number; // botol Yakult Light (backward compatible)
  soldYO?: number; // YO = MERAH (#D92D32) - Yakult Original
  soldOM?: number; // OM = ORANYE (#F28C28) - Yakult Original Mangga
  soldOS?: number; // OS = PINK (#E875A9) - Yakult Original Strawberry
  soldYT?: number; // YT = BIRU (#2689D8) - Yakult Light
  returnStock: number; // sisa botol
  brokenStock: number; // botol rusak/pecah
  cashDeposit: number; // rupiah setoran
  notes?: string;
  ownerUid?: string;
  createdAt: string;
  isDemo?: boolean;
}

export interface TargetYL {
  id: string;
  memberId: string;
  memberName: string;
  periodMonth: string; // YYYY-MM
  dailyBottleTarget: number;
  monthlyBottleTarget: number;
  targetYO?: number; // Target YO (Merah)
  targetOM?: number; // Target OM (Oranye)
  targetOS?: number; // Target OS (Pink)
  targetYT?: number; // Target YT (Biru)
  newCustomerTarget: number;
  propagandaTarget: number;
  updatedAt?: string;
  isDemo?: boolean;
}

export interface PlasticsAndBottles {
  id: string;
  memberId: string;
  memberName: string;
  date: string;
  smallPlasticReceived: number;
  largePlasticReceived: number;
  coolerBagStatus: string; // 'Baik' | 'Perlu Servis' | 'Ganti Baru'
  emptyBottlesCollected: number;
  cratesReceived: number;
  cratesReturned: number;
  notes?: string;
  ownerUid?: string;
  isDemo?: boolean;
}

export interface Customer {
  id: string;
  memberId: string;
  memberName: string;
  customerName: string;
  phone: string;
  address: string;
  routeArea: string;
  deliveryDays: string; // cth: 'Senin, Kamis'
  regularBottleCount: number; // botol per dropping
  customerType: 'Rumah Tangga' | 'Toko/Warung' | 'Kantor' | 'Sekolah' | 'Lainnya';
  notes?: string;
  ownerUid?: string;
  isDemo?: boolean;
}

export interface Propaganda {
  id: string;
  memberId: string;
  memberName: string;
  date: string;
  location: string;
  topic: string;
  audienceCount: number;
  sampleBottlesGiven: number;
  brochuresGiven: number;
  newProspectsCount: number;
  notes?: string;
  ownerUid?: string;
  isDemo?: boolean;
}

export interface PdmRecord {
  id: string;
  memberId: string;
  memberName: string;
  date: string; // YYYY-MM-DD
  pdmYO: number; // YO = MERAH (#D92D32) - Yakult Original
  pdmOM: number; // OM = ORANYE (#F28C28) - Yakult Original Mangga
  pdmOS: number; // OS = PINK (#E875A9) - Yakult Original Strawberry
  pdmYT: number; // YT = BIRU (#2689D8) - Yakult Light
  totalPDM: number; // pdmYO + pdmOM + pdmOS + pdmYT
  notes?: string;
  ownerUid?: string;
  createdAt: string;
  updatedAt?: string;
  isDemo?: boolean;
}

export interface ReturnBottleCalculation {
  memberId: string;
  memberName: string;
  date: string;
  pdmYO: number;
  soldYO: number;
  returnYO: number;
  pdmOM: number;
  soldOM: number;
  returnOM: number;
  pdmOS: number;
  soldOS: number;
  returnOS: number;
  pdmYT: number;
  soldYT: number;
  returnYT: number;
  totalPDM: number;
  totalSold: number;
  totalReturn: number;
  hasNegativeDiscrepancy: boolean;
  hasPdmRecord: boolean;
  hasDailyInput: boolean;
  pdmRecordId?: string;
  dailyInputId?: string;
}

export type MenuId =
  | 'dashboard'
  | 'input_harian'
  | 'pdm'
  | 'kembali_botol'
  | 'ringkasan'
  | 'target_yl'
  | 'pelanggan'
  | 'propaganda'
  | 'grafik'
  | 'data_anggota'
  | 'pengaturan'
  | 'plastik_botol';

export interface MenuItem {
  id: MenuId;
  label: string;
  description: string;
  badge?: string;
  iconName: string;
  adminOnly?: boolean;
}
